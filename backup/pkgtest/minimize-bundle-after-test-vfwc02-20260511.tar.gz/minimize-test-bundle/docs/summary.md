# host-minimize-safe v5.x 릴레이 테스트 누적 요약

## Server: test-nn (generic/범용 Ubuntu 서버) — 2026-04-23

### Phase A: 진단
- 번들 모드: 첫 번째 서버
- OS: Ubuntu 24.04.4 LTS
- 환경 체크: ✅ (디스크 79GB 여유, sudo OK, dpkg 이상없음)
- 초기 패키지 수: 690개 (ii 상태 기준, rc 상태 제외)
- rc 상태 잔류: ceph-base, ceph-common, ceph-mds, podman (이미 삭제됨)

### Phase B: 패키지 정합성
- 기준 파일: k-nn01-con301-krw1b_apt_list.txt
- 테스트 목적 재정의: apt_list.txt 비교 불필요 — 현재 시스템 기준으로 CSAP 분석
- 조치: 현재 690개 패키지 그대로 진행

### Phase C: Dry-run
- 프로파일: generic (auto 감지, kubelet 없음)
- k8s-worker 프로파일 직접 지정 시 CRIT 중단 → BUG-02 발견
- 제거 대상: 직접 20개 + 연쇄 24개(v5.0.1 기준) = 44개
- 스크립트 cascade count 오류: 64개(v5.0) → 24개(v5.0.1) → BUG-03 수정
- sysstat, htop: Jerry 지시로 유지(제외)
- ubuntu-server, ubuntu-standard 메타패키지 연쇄 제거: 피할 수 없음(실질 영향 없음) → KI-02

### Phase D: Execute
- 실행 여부: 예 (CSAP 대상 패키지 제거)
- 제거 목록: ftp, telnet, inetutils-telnet, apport 계열, git, snapd, byobu, screen, tmux, strace, crash, bpftrace, bpfcc-tools, trace-cmd, bind9-dnsutils, bind9-host
- sysstat, htop 제외
- 총 43개 제거, 427MB 디스크 반환
- 사후 검증: sshd:22 ✅, dpkg --audit ✅, apt-get check ✅, Failed 유닛 없음 ✅

### Phase E: Rollback 검증
- 스크립트 내장 rollback (v5.0): ❌ 0 newly installed — 복원 실패 → BUG-01 발견
- 수동 복원: ✅ 690개 정확 복원
- v5.0.1 rollback 스크립트로 재검증: ✅ 복원 성공 (추가 27개 Recommends 설치 → KI-01)
- rollback diff: 누락 0건 ✅

### Phase F: Edge Case (주요 항목)
- F.1 (set -e 버그 회귀): dry-run 완주 ✅
- F.7 (invalid profile): `--profile foo` → 오류 출력 ✅
- rc 상태 패키지 오인식: BUG-05 발견 및 수정 ✅

### 발견 버그 (5건)
| ID | 심각도 | 설명 | 상태 |
|----|--------|------|------|
| BUG-01 | P1 | rollback dselect-upgrade 복원 실패 | ✅ Fixed in v5.0.1 |
| BUG-02 | P2 | k8s-worker 프로파일 kubelet 체크 과도 | ✅ Fixed in v5.0.1 |
| BUG-03 | P2 | cascade count 중복 합산 오류 | ✅ Fixed in v5.0.1 |
| BUG-04 | P3 | NIC Link Down 오탐 (시간 필터 없음) | ✅ Fixed in v5.0.1 |
| BUG-05 | P2 | rc 상태 패키지 제거 후보에 포함 | ✅ Fixed in v5.0.1 |

### 다음 서버로 인계 사항
- v5.0.1 스크립트 사용
- sysstat, htop은 제외 대상 (운영 도구)
- ubuntu-server/ubuntu-standard 메타패키지 제거는 정상 (KI-02)
- rollback 후 Recommends 추가 설치분은 수동 purge 필요 (KI-01)
- Dell 관리도구(srvadmin-*, openwsman 등)는 rc 상태 — 건드리지 않음

---

## Server: test-nn2 (k8s-worker) — 2026-04-23

### Phase A: 진단
- 번들 모드: 계주 서버 (test-nn 인수)
- 이전 서버 이슈 검토: v5.0.1 BUG-01~05 전량 Fixed 확인
- 환경 체크: ✅

### Phase B: 패키지 정합성
- 기준: k-nn02-con301-krw1b_apt_list.txt
- 조치: 현재 시스템 기준 CSAP 분석 진행
- 결과: ✅

### Phase C: Dry-run
- 프로파일: k8s-worker (명시)
- 직접 제거: 19개 / 연쇄: 27개 / 총 46개
- 필수 패키지 보호 체크리스트: 전항목 ✅

### Phase D: Execute
- 실행 여부: 예 (v5.0.2, --yes --skip-snapshot-check)
- 직접 19개 + autoremove 28개(비가시적) = 47개 제거
- 스크립트 정상 완료 (03:59:43) → 9분 후 서버 hard hang
- 원인: BUG-A(autoremove→systemd-coredump 제거) + BUG-B(kubelet storm 572회)
- 강제 재부팅 수행
- 결과: ⚠ (hang 발생)

### Phase E: Rollback
- 결과: ❌ (hang으로 skip)

### Phase F: Edge Case
- 결과: ❌ (hang으로 skip)

### 발견 버그 (7건, 전량 수정)
- BUG-A (P0): autoremove whitelist 우회 → Fixed v5.0.3
- BUG-B (P1): kubelet restart storm 미탐지 → Fixed v5.0.3/5.0.4
- BUG-C (P1): get_removal_order O(N²) 중복 → Fixed v5.0.3
- BUG-D (P1): apt timeout 없음 → Fixed v5.0.3
- BUG-E (P1): snapd 사전 확인 없음 → Fixed v5.0.3
- BUG-F (P2): autoremove 목록 미표시 → Fixed v5.0.3
- BUG-G (P2): 패키지당 timeout 없음 → Fixed v5.0.3

### 다음 서버로 인계 사항
- v5.0.4 사용 (kubelet storm 자동 차단 포함)
- Phase E (rollback) 반드시 수행 — 이번 서버 skip됨
- autoremove whitelist 보호 동작 재확인 필요

---

## Server: test-nn3 (k8s-worker) — 2026-04-23

### Phase A: 진단
- 번들 모드: 계주 (test-nn2 인수)
- 이전 서버 이슈 검토: v5.0.4 BUG-A~G 전량 Fixed 확인
- 환경 체크: ✅ (디스크 79GB, sudo OK, 690패키지, dpkg audit 이상없음)

### Phase B: 패키지 정합성
- 기준: test-nn3_apt_list.txt (690개)
- 현재: 690개 (ii 기준)
- 설치 필요: 0개 / 제거 후보: 0개
- 조치: none (완전 정합)

### Phase C: Dry-run
- 프로파일 감지: auto=k8s-worker ✅ (예상 일치)
- 제거 대상: 직접 20개 + 연쇄 28개 = 총 48개
- 스크립트 버전: v5.0.4 → v5.0.5 (BUG-H 수정)
- 검증 체크리스트: 전항목 ✅
- BUG-H 발견: plan 파일 cascade_count 64 vs summary 28 불일치 → Fixed v5.0.5

### Phase D: Execute
- 실행 여부: 예 (kubelet NRestarts=6261 → v5.0.4 자동 탐지/mask 후 실행)
- autoremove: 0패키지 (whitelist 93개 apt-mark manual 보호 완전 동작 ✅)
- 직접 20 + cascade 2(ubuntu-server/standard) = 22패키지 제거
- 사후 검증: sshd:22 ✅, chrony ✅, apparmor ✅, dpkg audit ✅, Failed 유닛 0 ✅
- BUG-I 발견: 개별 apt-get purge 시 가상 패키지(core-dump-handler) gap → systemd-coredump 자동 설치 → Fixed v5.0.6 (배치 purge)
- BUG-J 발견: sysstat 제거 후 timer failed 잔류 → KI-05, reset-failed 수동 처리
- v5.0.6 재검증: 배치 purge로 신규 패키지 없음 확인 ✅

### Phase E: Rollback
- 스크립트 내장 rollback: ✅ 22패키지 전량 복원
- 외부 diff: dpkg-selections diff 2줄 (BUG-I 잔류, 수동 정리), apt-manual diff 184줄 (apt-mark manual 부작용)
- 실질적 복원 결과: comm 비교 diff 0건 ✅

### Phase F: Edge Case
- F.1 (set-e 회귀): ✅
- F.2 (grep 매칭): ✅ (--full-tree ftp/telnet 정상)
- F.3 (로케일): ✅ (ko_KR.UTF-8 동일 결과)
- F.7 (invalid profile): ✅ (exit 2)
- F.9 (plain log ANSI): ✅ (0건)

### 발견 버그 (3건)
| ID | 심각도 | 설명 | 상태 |
|----|--------|------|------|
| BUG-H | P2 | plan 파일 cascade_count 불일치 (64 vs 28) | ✅ Fixed v5.0.5 |
| BUG-I | P2 | 개별 apt-get purge → 가상 패키지 gap → 신규 패키지 자동 설치 | ✅ Fixed v5.0.6 (배치 purge) |
| BUG-J | P3 | sysstat timer failed 잔류 | KI-05 등록, reset-failed 수동 처리 |

### 다음 서버로 인계 사항
- v5.0.6 사용 (배치 purge + pending 업그레이드 탐지 + 신규 패키지 검증)
- BUG-I (KI-04): v5.0.6 자동 탐지/경고. 운영환경 변경관리 절차에 따라 pending 업그레이드 선처리 권장
- BUG-J (KI-05): execute 후 `sudo systemctl reset-failed` 실행 권장
- kubelet unmask 필요: `sudo systemctl unmask kubelet`
- apt-mark manual 대량 변경됨 — autoremove 동작 시 추가 제거 없을 것

---

## Server: test-scn (k8s-worker) — 2026-04-27

### Phase A: 진단
- 번들 모드: 계주 (test-nn3 인수)
- 이전 서버 이슈 검토: BUG-H/I/J 전량 처리 확인
- 특이사항: v5.0.7이 CHANGELOG에 누락되어 있어 항목 추가 (verbose 모드, BUG-J 자동처리)
- 환경 체크: ✅ (디스크 79GB, sudo OK, 691패키지, dpkg audit 이상없음)

### Phase B: 패키지 정합성
- 기준 파일: test-scn_apt_list.txt (691개)
- 현재: 691개 (ii 기준)
- 설치 필요: 0개 / 제거 후보: 0개
- 조치: none (완전 정합)

### Phase C: Dry-run
- 프로파일 감지: auto=generic (kubelet 비활성, BUG-02 정상 동작), 명시=k8s-worker ✅
- 제거 대상: 직접 20개 + 연쇄 28개(시뮬) = 총 48개
- kubelet restart storm: NRestarts=99 탐지 (정상 동작)
- pending 업그레이드: 28개 WARN
- 검증: 전항목 ✅

### Phase D: Execute
- 실행 여부: 예 (v5.0.7, --yes --skip-snapshot-check)
- kubelet mask: NRestarts=137 → --yes 자동 승인
- batch purge 20개 (18초), autoremove 0개 (whitelist 92개 보호)
- 실제 제거: 22개 (691→669), 신규 패키지 0개
- BUG-J 자동처리 확인: failed 유닛 1개 → reset-failed 자동 실행 ✅
- 사후 검증: sshd:22 ✅, apparmor ✅, dpkg audit ✅, Failed 유닛 0 ✅

### Phase E: Rollback
- 스크립트 내장: ✅ 22패키지 전량 복원
- 외부 diff: dpkg-selections **0줄** ✅, apt-manual **0줄** ✅ (test-nn3 대비 완전 개선)

### Phase F: Edge Case
- 통과: F.1, F.2, F.3, F.7, F.9
- 스킵: F.4(cephadm 전용), F.5/F.6/F.10(파괴적), F.8(변경없음)

### 발견 버그
- **신규 버그 0건** ← 수렴 추세 시작

### 다음 서버로 인계 사항
- v5.0.7 사용 (CHANGELOG 완비)
- kubelet unmask 필요: `sudo systemctl unmask kubelet`
- reset-failed는 v5.0.7부터 자동 처리
- 신규 버그 0건 확인 — 다음 서버(test-wproxy)에서 2회 연속 0건 확인 시 수렴 판정

---

## vfwc01 (compute / GUI) — 2026-04-29

### 서버 환경
- OS: Ubuntu 24.04.4 LTS Noble, 커널 6.8.0-110-generic
- 역할: compute (GNOME Desktop / GUI 환경)
- 설치 패키지: 1,663개
- 투입 버전: v5.0.8 / 산출 버전: v5.0.9
- 릴레이 순서: 5번째 (test-scn → vfwc01 직행, test-wproxy/log/cepho 미테스트)

### Phase A–B: 환경 진단 / 프로파일 감지
- compute 자동 감지 ✅, 1,663 패키지 ✅

### Phase C: Dry-run
- **BUG-K (P1) 발견 2회 crash 후 수정**:
  - 1차: `libpam-gnome-keyring → gnome-keyring` false CRIT (--no-recommends 누락)
  - 2차: pipefail propagation (|| true 누락)
- v5.0.8 수정 후: 직접 76개 + 연쇄 52개 = 총 128개

### Phase D: Execute
- 실행: 76패키지 41초 제거, autoremove 0 (whitelist 107개 보호)
- **BUG-L (P2) 발견**: gnome 가상 패키지 gap → notification-daemon, policykit-1-gnome 자동 설치
  - 수동 `dpkg --purge`로 정리 (`apt-get purge` 오사용 → pending upgrade 트리거 주의)
  - KI-06으로 등록, v5.1 검토 예정

### Phase E: Rollback
- 1,663패키지 복구 ✅, dpkg-selections diff: 0줄 ✅

### Phase F: 사후 검증
- **BUG-M (P3) 발견**: prerm hook ANSI 코드 plain log 오염
- v5.0.9 패치: `apt_exec()` silent 모드에 ANSI strip sed 추가

### 발견 버그
- BUG-K (P1): --no-recommends + || true → v5.0.8 수정 완료
- BUG-L (P2): gnome 가상 패키지 gap → KI-06 등록, 미수정
- BUG-M (P3): ANSI plain log 오염 → v5.0.9 수정 완료

### 다음 서버로 인계 사항
- v5.0.9 사용 (최신본)
- test-wproxy, test-log, test-cepho 미테스트 — 릴레이 계획 재확인 필요
- BUG-L (KI-06) v5.1에서 gnome 가상 패키지 gap 방지 방법 검토

---

## Server: test-vfwc02 (compute) — 2026-05-11

### Phase A: 진단
- 번들 모드: 계주 (vfwc01 인수)
- 이전 서버 이슈 검토: BUG-K/M 수정 확인, BUG-L (KI-06) 미수정 상태 인수
- 환경 체크: ✅ (디스크 76G 여유, sudo OK, 1663패키지, dpkg audit 이상없음)

### Phase B: 패키지 정합성
- 기준 파일: test-vfwc02_apt_list.txt (1,663개)
- 현재: 1,663개 (ii 기준)
- 설치 필요: 0개 / 제거 후보: 0개
- 조치: none (완전 정합)

### Phase C: Dry-run
- 프로파일 감지: auto=compute ✅, 명시=compute ✅
- 제거 대상: 직접 76개 + 연쇄 52개 = 총 128개
- vfwc01과 100% 동일 — 재현성 확인
- 검증: 전항목 ✅

### Phase D: Execute
- 실행 여부: 예 (v5.0.9, --yes --skip-snapshot-check)
- batch purge 76개 (41초), autoremove 0개 (whitelist 107개 보호)
- 1663 → 1555개 (108개 감소, KI-06 수동 정리 포함)
- BUG-L 재현: notification-daemon, policykit-1-gnome 자동 설치
- **BUG-N 신규 발견**: update-manager 등 4개 패키지 DEFAULT_SAFE_REMOVE 누락 → batch dpkg --purge로 수동 정리
- 사후 검증: sshd:22 ✅, dpkg audit ✅, Failed 유닛 0 ✅

### Phase E: Rollback
- 스크립트 내장: ✅ 완전 복원 (1663개)
- 외부 diff: dpkg-selections **0줄** ✅, apt-manual **244줄** (정상, whitelist apt-mark 잔류)

### Phase F: Edge Case
- 통과: F.1, F.2, F.3, F.7, F.9
- 스킵: F.4(cephadm 전용), F.5/F.6/F.10(파괴적), F.8(변경없음)

### 발견 버그
- **BUG-N (P2)**: compute 프로파일 DEFAULT_SAFE_REMOVE에 update-manager, update-notifier, ubuntu-release-upgrader-gtk, network-manager-gnome 누락 → v5.0.10 수정 완료 (직접 76→80개)

### 다음 서버로 인계 사항
- v5.0.10 사용 (BUG-N 수정본)
- 미테스트 서버: test-wproxy, test-log, test-cepho — 계획 재확인 필요
- test-cepho에서 podman 보호 F.4 검증 필수
