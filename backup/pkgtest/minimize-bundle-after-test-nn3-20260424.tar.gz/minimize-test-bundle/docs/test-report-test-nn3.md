# Test Report — test-nn3 (k8s-worker) — 2026-04-23

## 개요
- **서버**: test-nn3
- **프로파일**: k8s-worker
- **스크립트 버전 IN**: v5.0.4 → **OUT**: v5.0.5
- **번들 모드**: 계주 (test-nn2 인수)

## Phase 결과 요약
| Phase | 결과 | 비고 |
|-------|------|------|
| A: 진단 | ✅ | 계주 모드, v5.0.4 번들 확인 |
| B: 정합성 | ✅ | 690개 패키지, diff 0건 |
| C: Dry-run | ✅ | 20직접+28연쇄=48총, BUG-H 발견/수정 |
| D: Execute | ✅ | 22패키지 제거, autoremove 0건 (BUG-A 보호 동작), BUG-I/J 발견 |
| E: Rollback | ✅ | 22패키지 복원, diff 0건 (BUG-I 잔류 수동 정리) |
| F: Edge Case | ✅ | F.1/F.2/F.3/F.7/F.9 통과 |

## 발견 버그
| ID | 심각도 | 설명 | 상태 |
|----|--------|------|------|
| BUG-H | P2 | plan 파일 cascade_count 불일치 (64 vs 28) | ✅ Fixed in v5.0.5 |
| BUG-I | P2 | apt-get purge 시 pending systemd 업그레이드 및 신규 패키지 자동 설치 | KNOWN-ISSUES 등록 |
| BUG-J | P3 | sysstat 제거 후 timer 유닛 failed 상태 잔류 | KNOWN-ISSUES 등록 |

## 주요 검증 사항
- **autoremove whitelist 보호 (BUG-A)**: autoremove 0개 → ✅ 완전 동작
- **kubelet mask (BUG-B/v5.0.4)**: NRestarts=6261 storm 상태에서 사전 mask → hang 없이 성공
- **plan 파일 정확도 (BUG-H)**: cascade_count 28 정확하게 기록 ✅
- **rollback (BUG-01)**: 22패키지 전량 복원, diff 0건 ✅

## 인계 사항
- v5.0.5 사용
- BUG-I: execute 전 pending 업그레이드 사전 확인 권장 (`apt-get -s upgrade`)
- apt-mark manual 상태 변경 대량 발생 — autoremove 동작에 주의
- kubelet mask 상태 → unmask 필요 (`sudo systemctl unmask kubelet`)
