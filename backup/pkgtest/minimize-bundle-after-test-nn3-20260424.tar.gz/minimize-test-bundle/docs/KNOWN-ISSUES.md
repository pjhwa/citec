# KNOWN-ISSUES — host-minimize-safe v5.x

## KI-01: rollback 시 Recommends 의존성으로 의도치 않은 패키지 추가 설치
- **발견 서버**: test-nn
- **발견 Phase**: E (Rollback 검증)
- **심각도**: P3
- **증상**: `apt-get install` rollback 실행 시 원본에 없던 27개 패키지 추가 설치 (폰트, 미디어 라이브러리 등)
- **원인**: `apt-get install`이 Recommends를 기본 설치하는 APT 동작
- **수정 적용**: v5.0.1에서 `--no-install-recommends` 추가로 최소화됨
- **잔여 위험**: --no-install-recommends 적용 후에도 Depends 연쇄로 극소수 추가 가능
- **우회 방법**: rollback 후 `dpkg -l | awk '/^ii/ {print $2}'`와 백업 dpkg-l.txt를 비교해 초과분 수동 purge
- **프로덕션 영향**: 제한적 (추가 패키지가 서비스에 영향 없으나 공격면 미세 증가)
- **재검토 예정**: v5.2에서 선택적 복원 방식 개선 검토

## KI-02: ubuntu-server / ubuntu-standard 메타패키지 연쇄 제거
- **발견 서버**: test-nn
- **발견 Phase**: C (Dry-run)
- **심각도**: P3
- **증상**: CSAP 대상 패키지(ftp, apport, git 등) 제거 시 ubuntu-server/ubuntu-standard 메타패키지 연쇄 제거됨
- **원인**: 두 메타패키지가 CSAP 제거 대상 패키지들을 Depends로 선언
- **수정 안 한 이유**: 메타패키지는 기능이 없는 껍데기 — 실질적 서비스 영향 없음. 보존 불가능(Depends 충돌)
- **우회 방법**: 없음 (의도된 동작으로 간주)
- **프로덕션 영향**: 없음 (실제 설치된 패키지는 그대로 유지)
- **재검토 예정**: 없음

## KI-03: NIC Link Down 타임스탬프 파싱 실패 시 false negative
- **발견 서버**: test-nn
- **발견 Phase**: C (BUG-04 수정 과정)
- **심각도**: P3
- **증상**: dmesg -T 타임스탬프 파싱 실패 시(로케일/포맷 차이) linkdown_recent=false로 처리
- **원인**: `date -d "$ts"` 파싱이 dmesg 타임스탬프 포맷에 의존
- **수정 안 한 이유**: 파싱 실패 시 안전 방향(false negative, 즉 체크 스킵)으로 동작
- **우회 방법**: `--skip-ssh-check` 사용 후 수동으로 `dmesg -T | grep -i "link down"` 확인
- **프로덕션 영향**: 제한적 (SSH 안정성 체크 미작동 — 관리자가 수동 확인 필요)
- **재검토 예정**: v5.2

## KI-02: restart storm 서비스 존재 시 --execute hang 위험
- **발견 서버**: test-nn2 (재부팅 사후 분석)
- **발견 Phase**: D (--execute 실행 후)
- **심각도**: P0
- **증상**: kubelet이 NRestarts=572의 restart loop 상태에서 --execute 실행.
  autoremove가 systemd-coredump를 제거하며 daemon-reload 트리거 → systemd deadlock
  → 서버 hard hang (journal corrupted/unclean shutdown 확인됨)
- **원인**: 두 가지 결함의 복합:
  1. autoremove가 whitelist를 우회하여 systemd-coredump 제거
  2. kubelet restart storm을 탐지/차단하지 않아 과부하된 systemd에 추가 부하
- **수정**: v5.0.3에서 BUG-A(autoremove whitelist 보호) + BUG-B(storm 탐지) 수정
- **우회 방법**: --execute 전 `sudo systemctl mask <storm_service>` 로 재시작 중단
- **프로덕션 영향**: 있음 — 프로덕션에서도 미설정 서비스가 있으면 동일 위험
- **재검토 예정**: v5.1 최종 검증 포함

## KI-03: autoremove가 apt whitelist 외부에서 패키지 제거
- **발견 서버**: test-nn2 (dpkg.log 분석)
- **발견 Phase**: D (autoremove 단계)
- **심각도**: P0
- **증상**: autoremove가 28개 패키지를 추가 제거. 이 중 systemd-coredump, python3-systemd
  등 whitelist에 systemd* 패턴으로 보호되어야 할 패키지 포함.
  autoremove는 apt의 auto-install tracking을 사용하며 스크립트 whitelist를 완전히 무시.
- **원인**: 스크립트 whitelist는 DEFAULT_SAFE_REMOVE candidates를 필터링하는 용도로만
  사용됨. autoremove는 별도의 apt internal 상태를 참조하여 독립적으로 동작.
- **수정**: v5.0.3 BUG-A — protect_whitelist_packages()로 autoremove 전 apt-mark manual
- **우회 방법**: v5.0.3 이전 버전 사용 시 실행 전 `sudo apt-mark manual <중요패키지>`
- **프로덕션 영향**: 있음 — 모든 프로덕션 노드에서 동일 위험
- **재검토 예정**: v5.1 검증 시 apt-mark manual 적용 효과 재확인 필요

## KI-04: apt-get purge 실행 시 pending 업그레이드가 동시 처리되어 신규 패키지 설치
- **발견 서버**: test-nn3
- **발견 Phase**: D (Execute 후 사후 검증)
- **심각도**: P2
- **증상**: `apt-get purge apport-core-dump-handler` 실행 시 pending 중이던 systemd 업그레이드(255.4-8.14→8.15)가 함께 처리되면서 신규 패키지(`systemd-coredump`, `python3-zstandard`) 자동 설치됨
- **원인**: apt-get은 패키지 해결 시 pending 업그레이드를 동시에 처리. Ubuntu 24.04에서 systemd가 split되면서 `systemd-coredump`가 별도 패키지로 추가됨
- **수정 안 한 이유**: apt 기본 동작이므로 스크립트에서 완전 차단 불가. execute 전 `apt-get upgrade` 수행을 권고하는 방향이 적절하나 현재 구현 없음
- **우회 방법**: execute 실행 전 `sudo apt-get upgrade -y` 로 pending 업그레이드 먼저 처리 후 스크립트 실행
- **프로덕션 영향**: 있음 — pending 업그레이드 상태에서 execute 시 예상치 못한 패키지 추가 설치 가능
- **재검토 예정**: v5.1 전 execute 진입 시 pending upgrade 사전 확인 및 경고 추가

## KI-05: 패키지 purge 후 systemd timer 유닛 failed 상태 잔류
- **발견 서버**: test-nn3
- **발견 Phase**: D (Execute 사후 검증)
- **심각도**: P3
- **증상**: `sysstat` 제거 후 `sysstat-collect.timer`, `sysstat-summary.timer`가 `systemctl list-units --failed`에 잔류 (not-found, failed 상태). `daemon-reload` 후에도 지속
- **원인**: systemd가 이전에 active였던 timer 유닛을 failed 상태로 기억. purge 후 unit 파일이 없어도 상태 유지
- **수정 안 한 이유**: sysstat 외 패키지에서 일반적으로 재현하기 어려움. purge 전 disable 처리가 이상적이나 현재 스크립트에 없음
- **우회 방법**: execute 후 `sudo systemctl reset-failed` 실행으로 정리. 또는 개별 유닛 `systemctl reset-failed <unit>` 사용
- **프로덕션 영향**: 없음 (실제 서비스 영향 없음, 모니터링 오탐 가능)
- **재검토 예정**: v5.1 사후검증에 `systemctl reset-failed` 추가 검토
