# CHANGELOG — host-minimize-safe

## v5.0.1 (2026-04-23) @ test-nn

### BUG-01 (P1) Fix: rollback 스크립트가 purge된 패키지를 복원하지 못하는 문제
- **증상**: `dpkg --set-selections` + `apt-get dselect-upgrade` 조합이 `0 newly installed` — 실제 재설치 없음
- **원인**: `dselect-upgrade`는 purge 이후 "install" 선택 상태를 무시하는 경우 발생
- **수정**: rollback 로직을 `apt-get install` 직접 호출 방식으로 교체
  - pre-removal-selections.txt 에서 `install` 상태 패키지만 추출
  - 현재 미설치(`!ii`) 패키지만 재설치 (`--no-install-recommends`)
  - apt-mark manual 복원 시 미설치 패키지 무시 처리

### BUG-02 (P2) Fix: `--profile k8s-worker` 명시 시 kubelet 비활성이면 CRIT 중단
- **증상**: 테스트 환경(kubelet 미설치)에서 `--profile k8s-worker` 사용 불가
- **원인**: `check_k8s_health()`가 PROFILE 구분 없이 모두 CRIT 처리
- **수정**: `--profile auto` 감지 경우만 CRIT, 명시적 선택 시 WARN 후 계속 진행

### BUG-03 (P2) Fix: DRY-RUN SUMMARY cascade count 과다 계산
- **증상**: 실제 43개 영향인데 스크립트가 84개(연쇄 64개)로 표시
- **원인**: 각 패키지별 cascade를 개별 합산 → 공유 의존성 중복 카운트
- **수정**: 전체 패키지를 한 번에 `apt-get -s purge --auto-remove`로 시뮬레이션하여 실제 제거 수 계산

### BUG-04 (P3) Fix: NIC Link Down 오탐으로 CRIT 처리
- **증상**: 부팅 초기 일회성 NIC link down 로그로 인해 항상 CRIT 발생
- **원인**: dmesg 최근 200줄 전체를 검색 — 시간 필터 없음
- **수정**: 최근 30분 이내 로그만 검사, 타임스탬프 파싱으로 정확도 개선

### BUG-05 (P2) Fix: `build_candidates()`가 rc 상태 패키지를 설치된 것으로 오인식
- **증상**: purge 후 설정파일만 남은(rc) 패키지가 제거 후보에 포함
- **원인**: `dpkg-query -W`는 rc 상태도 반환
- **수정**: `dpkg -l`의 `ii` 상태만 필터링하도록 변경

---

## v5.0 (2026-04-21) — 테스트 시작 버전

- v4.2 치명적 버그 4건 수정
- Risk Report 모드 추가 (`--risk-report`)
- 노드 타입 세분화 (cephadm, k8s-worker, k8s-control, compute-bare, network)
- Extended baseline (services / ports / kernel modules / /etc / routes / mounts)
- Lock 파일, SSH 안정성 사전 점검, LVM snapshot 유도
- podman/docker/containerd 런타임 whitelist 보강
- ANSI 컬러 제거된 plain-text 병렬 로그
- Plan export (`--plan-out <file>.yaml`)
