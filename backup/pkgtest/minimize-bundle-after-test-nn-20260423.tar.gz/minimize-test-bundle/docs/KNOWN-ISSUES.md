# KNOWN-ISSUES — host-minimize-safe v5.x

## KI-01: rollback 시 Recommends 의존성으로 의도치 않은 패키지 추가 설치
- **발견 서버**: test-nn
- **발견 Phase**: E (Rollback 검증)
- **심각도**: P3
- **증상**: `apt-get install` rollback 실행 시 원본에 없던 27개 패키지 추가 설치 (폰트, 미디어 라이브러리 등)
- **원인**: `apt-get install`이 Recommends를 기본 설치하는 APT 동작
- **수정 적용**: v5.0.1에서 `--no-install-recommends` 추가로 최소화됨
- **잔여 위험**: --no-install-recommends 적용 후에도 Depends 연쇄로 극소수 추가 가능
- **우회 방법**: rollback 후 `dpkg -l | awk '/^ii/ {print $2}'`와 백업 dpkg-l.txt를 비교해 초과분 수동 purge
- **프로덕션 영향**: 제한적 (추가 패키지가 서비스에 영향 없으나 공격면 미세 증가)
- **재검토 예정**: v5.2에서 선택적 복원 방식 개선 검토

## KI-02: ubuntu-server / ubuntu-standard 메타패키지 연쇄 제거
- **발견 서버**: test-nn
- **발견 Phase**: C (Dry-run)
- **심각도**: P3
- **증상**: CSAP 대상 패키지(ftp, apport, git 등) 제거 시 ubuntu-server/ubuntu-standard 메타패키지 연쇄 제거됨
- **원인**: 두 메타패키지가 CSAP 제거 대상 패키지들을 Depends로 선언
- **수정 안 한 이유**: 메타패키지는 기능이 없는 껍데기 — 실질적 서비스 영향 없음. 보존 불가능(Depends 충돌)
- **우회 방법**: 없음 (의도된 동작으로 간주)
- **프로덕션 영향**: 없음 (실제 설치된 패키지는 그대로 유지)
- **재검토 예정**: 없음

## KI-03: NIC Link Down 타임스탬프 파싱 실패 시 false negative
- **발견 서버**: test-nn
- **발견 Phase**: C (BUG-04 수정 과정)
- **심각도**: P3
- **증상**: dmesg -T 타임스탬프 파싱 실패 시(로케일/포맷 차이) linkdown_recent=false로 처리
- **원인**: `date -d "$ts"` 파싱이 dmesg 타임스탬프 포맷에 의존
- **수정 안 한 이유**: 파싱 실패 시 안전 방향(false negative, 즉 체크 스킵)으로 동작
- **우회 방법**: `--skip-ssh-check` 사용 후 수동으로 `dmesg -T | grep -i "link down"` 확인
- **프로덕션 영향**: 제한적 (SSH 안정성 체크 미작동 — 관리자가 수동 확인 필요)
- **재검토 예정**: v5.2
