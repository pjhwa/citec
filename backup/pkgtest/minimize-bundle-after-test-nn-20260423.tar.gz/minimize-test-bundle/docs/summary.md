# host-minimize-safe v5.x 릴레이 테스트 누적 요약

## Server: test-nn (generic/범용 Ubuntu 서버) — 2026-04-23

### Phase A: 진단
- 번들 모드: 첫 번째 서버
- OS: Ubuntu 24.04.4 LTS
- 환경 체크: ✅ (디스크 79GB 여유, sudo OK, dpkg 이상없음)
- 초기 패키지 수: 690개 (ii 상태 기준, rc 상태 제외)
- rc 상태 잔류: ceph-base, ceph-common, ceph-mds, podman (이미 삭제됨)

### Phase B: 패키지 정합성
- 기준 파일: k-nn01-con301-krw1b_apt_list.txt
- 테스트 목적 재정의: apt_list.txt 비교 불필요 — 현재 시스템 기준으로 CSAP 분석
- 조치: 현재 690개 패키지 그대로 진행

### Phase C: Dry-run
- 프로파일: generic (auto 감지, kubelet 없음)
- k8s-worker 프로파일 직접 지정 시 CRIT 중단 → BUG-02 발견
- 제거 대상: 직접 20개 + 연쇄 24개(v5.0.1 기준) = 44개
- 스크립트 cascade count 오류: 64개(v5.0) → 24개(v5.0.1) → BUG-03 수정
- sysstat, htop: Jerry 지시로 유지(제외)
- ubuntu-server, ubuntu-standard 메타패키지 연쇄 제거: 피할 수 없음(실질 영향 없음) → KI-02

### Phase D: Execute
- 실행 여부: 예 (CSAP 대상 패키지 제거)
- 제거 목록: ftp, telnet, inetutils-telnet, apport 계열, git, snapd, byobu, screen, tmux, strace, crash, bpftrace, bpfcc-tools, trace-cmd, bind9-dnsutils, bind9-host
- sysstat, htop 제외
- 총 43개 제거, 427MB 디스크 반환
- 사후 검증: sshd:22 ✅, dpkg --audit ✅, apt-get check ✅, Failed 유닛 없음 ✅

### Phase E: Rollback 검증
- 스크립트 내장 rollback (v5.0): ❌ 0 newly installed — 복원 실패 → BUG-01 발견
- 수동 복원: ✅ 690개 정확 복원
- v5.0.1 rollback 스크립트로 재검증: ✅ 복원 성공 (추가 27개 Recommends 설치 → KI-01)
- rollback diff: 누락 0건 ✅

### Phase F: Edge Case (주요 항목)
- F.1 (set -e 버그 회귀): dry-run 완주 ✅
- F.7 (invalid profile): `--profile foo` → 오류 출력 ✅
- rc 상태 패키지 오인식: BUG-05 발견 및 수정 ✅

### 발견 버그 (5건)
| ID | 심각도 | 설명 | 상태 |
|----|--------|------|------|
| BUG-01 | P1 | rollback dselect-upgrade 복원 실패 | ✅ Fixed in v5.0.1 |
| BUG-02 | P2 | k8s-worker 프로파일 kubelet 체크 과도 | ✅ Fixed in v5.0.1 |
| BUG-03 | P2 | cascade count 중복 합산 오류 | ✅ Fixed in v5.0.1 |
| BUG-04 | P3 | NIC Link Down 오탐 (시간 필터 없음) | ✅ Fixed in v5.0.1 |
| BUG-05 | P2 | rc 상태 패키지 제거 후보에 포함 | ✅ Fixed in v5.0.1 |

### 다음 서버로 인계 사항
- v5.0.1 스크립트 사용
- sysstat, htop은 제외 대상 (운영 도구)
- ubuntu-server/ubuntu-standard 메타패키지 제거는 정상 (KI-02)
- rollback 후 Recommends 추가 설치분은 수동 purge 필요 (KI-01)
- Dell 관리도구(srvadmin-*, openwsman 등)는 rc 상태 — 건드리지 않음
