# Edge Case Results — test-nn3 (k8s-worker)

| # | 검증 목적 | 결과 | 비고 |
|---|-----------|------|------|
| F.1 | v4.2 Bug#1 회귀 (set -e + (())) | ✅ | dry-run 완주 |
| F.2 | v4.2 Bug#2 회귀 (grep 매칭) | ✅ | --full-tree ftp/telnet 정상 |
| F.3 | v4.2 Bug#3 회귀 (로케일) | ✅ | LC_ALL=ko_KR.UTF-8 동일 결과 |
| F.4 | v4.2 Bug#4 회귀 (podman) | ⏭ | cephadm 서버에서 수행 예정 |
| F.5 | Lock 파일 (2세션 동시) | ⏭ | 파괴적, skip |
| F.6 | SSH 안정성 체크 | ⏭ | 파괴적, skip |
| F.7 | Invalid profile | ✅ | --profile foo → exit 2 확인 |
| F.8 | Exclude 병합 | ⏭ | 미수행 |
| F.9 | Plain log ANSI 없음 | ✅ | ANSI 코드 0건 확인 |
| F.10 | 사후검증 sshd down 탐지 | ⏭ | 파괴적, skip |

비고:
- F.7에서 '--profile foo' → ERROR 메시지 + help 출력 + exit 2 정상
- F.9에서 test 스크립트 판정 로직 오류로 false negative 출력됐으나 실제 ANSI 0건
