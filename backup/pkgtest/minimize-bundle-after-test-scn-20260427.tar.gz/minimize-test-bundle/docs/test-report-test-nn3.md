# 테스트 보고서: test-nn3 (k8s-worker) — 2026-04-23

## 서버 정보

| 항목 | 값 |
|------|-----|
| 호스트명 | test-nn (hostname) |
| 테스트 서버 ID | test-nn3 |
| 대상 프로파일 | k8s-worker |
| 대응 프로덕션 노드 | k-nn03-con301-krw1b (추정) |
| OS | Ubuntu 24.04.4 LTS Noble |
| 테스트 일시 | 2026-04-23 23:17 ~ 2026-04-24 00:04 (v5.0.6 재검증 포함) |
| 사용 스크립트 IN | v5.0.4 (번들 인수) |
| 사용 스크립트 OUT | v5.0.6 (BUG-H→v5.0.5, BUG-I→v5.0.6) |
| 번들 모드 | 계주 서버 (relay) — test-nn2 번들 인수 |

---

## Phase A — 환경 진단

- **번들 모드**: 계주 서버 (test-nn2 산출물 인수)
- **이전 서버 이슈 검토**: v5.0.4 인수, BUG-A~G 모두 Fixed 확인
  - BUG-A (autoremove whitelist 우회) → v5.0.3 Fixed
  - BUG-B (kubelet storm 미탐지) → v5.0.3/5.0.4 Fixed
  - BUG-C (get_removal_order O(N²) 중복) → v5.0.3 Fixed
  - BUG-D (apt timeout 없음) → v5.0.3 Fixed
  - BUG-E (snapd 사전 확인 없음) → v5.0.3 Fixed
  - BUG-F (autoremove 목록 미표시) → v5.0.3 Fixed
  - BUG-G (패키지당 timeout 없음) → v5.0.3 Fixed
- **OS 확인**: Ubuntu 24.04.4 LTS ✅
- **디스크 여유**: ~79 GB ✅
- **sudo 권한**: ✅
- **apt/dpkg 상태**: dpkg --audit 이상 없음 ✅
- **초기 패키지 수**: 690개 (ii 상태 기준)
- **rc 상태 잔류**: Dell 관리도구(srvadmin-* 계열) — 건드리지 않음
- **판정**: ✅

---

## Phase B — 패키지 정합성

| 항목 | 값 |
|------|-----|
| 기준 파일 | test-nn3_apt_list.txt (690개) |
| 현재 설치 | 690개 (ii 기준) |
| 설치 필요 | 0개 |
| 제거 후보 | 0개 |
| 조치 | none (완전 정합) |

- apt_list.txt 와 현재 시스템 완전 일치 (diff 0건)
- **판정**: ✅

---

## Phase C — Dry-run

| 항목 | 값 |
|------|-----|
| 프로파일 자동감지 | auto → k8s-worker ✅ (예상 일치) |
| 스크립트 버전 | v5.0.4 → v5.0.5 (BUG-H 발견 후 교체) |
| 직접 제거 대상 | 20개 |
| 연쇄 제거 예상 | 28개 |
| 총 영향 패키지 | 48개 |

### 제거 대상 목록 (직접 20개)

ftp, telnet, inetutils-telnet, apport, apport-symptoms, apport-core-dump-handler,
byobu, screen, tmux, strace, crash, bpftrace, bpfcc-tools, trace-cmd,
git, bind9-dnsutils, bind9-host, htop, sysstat, snapd

> ℹ️ htop, sysstat: test-nn (generic)에서는 Jerry 지시로 제외했으나 test-nn3 (k8s-worker) 프로파일에서는 기본 포함.

### BUG-H 발견

- **현상**: plan-k8s-worker.yaml에 `cascade_count: 64` 기록 — dry-run summary `연쇄 제거 예상: 28개`와 불일치
- **원인**: BUG-03(v5.0.1)에서 dry-run summary는 `actual_cascade`로 수정했으나 write_plan() 함수 내 plan 파일 출력은 여전히 `total_cascade`(중복 합산값) 사용
- **영향**: plan 파일을 참조하는 자동화 도구나 감사 기록에서 잘못된 cascade 수 제공
- **수정**: v5.0.5 — write_plan() 내 `echo "cascade_count: $total_cascade"` → `echo "cascade_count: $actual_cascade"` (line 994)
- **재검증**: v5.0.5 dry-run 후 plan-k8s-worker.yaml `cascade_count: 28` 확인 ✅

### 체크리스트

- [x] `openssh-server` 제거 대상 없음
- [x] `containerd*`, `kubelet`, `kubeadm`, `kubectl` 보호
- [x] `runc`, `cni-plugins`, `conntrack`, `socat` 보호
- [x] `chrony`, `apparmor`, `systemd` 계열 보호
- [x] `telnet`, `ftp`, `apport`, `snapd` 제거 대상 포함
- [x] Critical 역의존 0건
- [x] snapd: 설치된 snap 없음 → 안전하게 제거 가능 ✅

- **판정**: ✅

---

## Phase D — Execute

### 사전 조치 (kubelet NRestarts=6261)

```
23:17:54  kubelet RESTART STORM 탐지 (NRestarts=6261, 임계치=50)
          → 경고: test-nn2에서 NRestarts=572 상태로 실제 hang 발생 이력 있음
23:17:54  v5.0.4 자동 탐지: kubelet mask/stop 승인 요청 (--yes 모드 자동 승인)
23:17:54  kubelet stop → mask 완료 (LoadState=masked, ActiveState=inactive)
```

- k8s-worker 서버 특성상 kubelet restart storm 상태 예상됨
- v5.0.4의 check_k8s_health()가 NRestarts=6261 탐지 후 자동 mask/stop 처리 ✅
- test-nn2 hang 재현 없이 안전하게 진행

### 외부 백업

```
baseline-test-nn3-20260423-234304.tar.gz (dpkg-selections + apt-mark + /etc snapshot)
```

### 실행 정보 (v5.0.5 — execute)

```
23:21:34  스크립트 시작 (v5.0.5, --execute --profile k8s-worker)
23:21:34  제거 대상: 20개 (ii 상태 필터 후)
23:25:55  sysstat 제거 (개별 purge)
23:26:25  autoremove 전 whitelist 패키지 apt-mark manual 설정 시작
23:27:05  whitelist 패키지 93개 apt-mark manual 완료
23:27:07  autoremove 대상 없음 (whitelist 보호 완료) ✅
23:27:15  제거 작업 완료
```

### 제거된 패키지

- **직접 제거 (20개)**: ftp, telnet, inetutils-telnet, apport, apport-symptoms, apport-core-dump-handler, byobu, screen, tmux, strace, crash, bpftrace, bpfcc-tools, trace-cmd, git, bind9-dnsutils, bind9-host, htop, sysstat, snapd
- **연쇄 제거 (2개)**: ubuntu-server, ubuntu-standard (메타패키지 — KI-02 기존 이슈)
- **autoremove**: 0개 ✅ (whitelist 93개 apt-mark manual 보호 완전 동작)

### BUG-I 발견 (v5.0.5 execute 후 사후 분석)

- **현상**: dpkg.log 분석 시 `systemd-coredump`, `python3-zstandard` 2개 신규 패키지 자동 설치됨
- **원인 분석**:
  - `apport-core-dump-handler`와 `systemd-coredump`는 동일한 가상 패키지 `core-dump-handler`를 Provides/Conflicts
  - 개별 purge 방식(`apt-get purge apport-core-dump-handler`)으로 실행 시 apt는 `core-dump-handler`의 gap을 `systemd-coredump`로 채우려 시도
  - 동시에 pending 상태이던 systemd 업그레이드(255.4-8.14→8.15)가 함께 처리되면서 split 패키지 `systemd-coredump` 설치
  - `python3-zstandard`: systemd 업그레이드 연동 의존성
- **--no-upgrade 플래그 시도**: `0 upgraded, 2 newly installed` — 업그레이드와 무관하게 가상 패키지 gap 문제로 동일 발생
- **핵심 발견**: `apt-get -s purge ALL_PACKAGES_AT_ONCE` 시뮬레이션 → `0 upgraded, 0 newly installed, 22 to remove` — 배치 purge가 gap 방지
- **근본 원인**: 개별 purge 루프는 각 purge 단계마다 apt가 의존성 그래프를 재계산, 가상 패키지 빈자리를 대체 패키지로 채울 기회가 발생. 전체 배치 purge는 한 번에 제거 목록을 확정하여 이 문제를 방지.

> ℹ️ `sudo apt-get upgrade -y` 선행은 실제 운영환경에서 변경관리 절차 위반 — 해결책으로 채택 불가.

### 수정 내용 (v5.0.6)

- `real_removal()` 개별 purge 루프 → 단일 배치 호출로 교체:
  ```bash
  apt-get -y purge "${to_purge[@]}"
  ```
  배치 실패 시 fallback으로 개별 purge (오류 격리 목적)
- `check_pending_upgrades()` 신규 추가: execute 전 pending 업그레이드 수 탐지 → WARN 출력 (NON-BLOCKING — 변경관리 절차는 운영자 판단)
- `verify_no_new_packages()` 신규 추가: execute 전후 dpkg --get-selections 비교 → 신규 패키지 탐지 시 WARN

### v5.0.6 재검증 결과

```
23:59:39  스크립트 시작 (v5.0.6, --execute --profile k8s-worker)
23:59:40  kubelet RESTART STORM 탐지 (NRestarts=6261) → 자동 mask/stop ✅
23:59:43  pending 업그레이드 WARN 출력 (탐지, NON-BLOCKING) ✅
00:03:32  batch purge 실행 중 (timeout=600s)...
00:04:26  whitelist 패키지 92개 apt-mark manual 완료
00:04:28  autoremove 대상 없음 ✅
00:04:36  OK: 신규 패키지 없음 — execute 전후 패키지 집합 동일 ✅
00:04:36  제거 작업 완료
```

### BUG-J 발견 (v5.0.5 execute 사후 검증)

- **현상**: sysstat 제거 후 `systemctl list-units --failed` 에 `sysstat-collect.timer`, `sysstat-summary.timer` 잔류 (not-found/failed 상태). `daemon-reload` 후에도 지속
- **원인**: systemd가 이전에 active였던 timer 유닛의 failed 상태를 기억. unit 파일이 삭제된 후에도 in-memory 상태 유지
- **조치**: `sudo systemctl reset-failed sysstat-collect.timer sysstat-summary.timer` 수동 처리로 정리
- **KI-05 등록**: v5.1에서 사후검증 후 자동 reset-failed 추가 검토

### 사후 검증 결과 (v5.0.6 기준)

| 검증 항목 | 결과 |
|-----------|------|
| sshd:22 listen | ✅ |
| service ssh active | ✅ |
| service systemd-journald active | ✅ |
| service apparmor active | ✅ |
| 제거 대상 잔류 | 0개 ✅ |
| dpkg --audit | 이상 없음 ✅ |
| apt-get check | 이상 없음 ✅ |
| Failed 유닛 | 0개 ✅ (BUG-J 수동 정리 후) |
| 신규 패키지 | 없음 ✅ (v5.0.6 verify_no_new_packages) |

- **판정**: ✅

---

## Phase E — Rollback 검증

### 실행 정보

```
rollback-v5-20260423-231754.sh 실행
복원 대상: 22개
=== 복원 완료. reboot 권장. ===
```

### rollback-verification-dpkg.txt 분석

```diff
604a605
> python3-zstandard   install       ← BUG-I 잔류 (v5.0.5 execute 중 설치됨)
632a634
> systemd-coredump    deinstall     ← BUG-I 잔류 (deinstall 상태로 기록됨)
```

- **실질적 복원**: comm 비교 기준 diff 0건 ✅ (BUG-I 잔류 2건은 별도 수동 정리)
- **apt-mark 상태**: protect_whitelist_packages()의 apt-mark manual 대량 설정으로 diff 184줄 (whitelist 93개 manual 변경 — autoremove 동작에는 영향 없음)

### 수동 정리

```bash
# BUG-I 잔류분 정리
sudo apt-get purge python3-zstandard
# systemd-coredump deinstall 상태 → 이미 제거됨, 상태만 정리
sudo dpkg --purge systemd-coredump
```

### 판정: ✅

---

## Phase F — Edge Case

| # | 검증 목적 | 결과 | 비고 |
|---|-----------|------|------|
| F.1 | v4.2 Bug#1 회귀 (set -e + (())) | ✅ | dry-run 완주 |
| F.2 | v4.2 Bug#2 회귀 (grep 매칭) | ✅ | --full-tree ftp/telnet 정상 |
| F.3 | v4.2 Bug#3 회귀 (로케일) | ✅ | LC_ALL=ko_KR.UTF-8 동일 결과 |
| F.4 | v4.2 Bug#4 회귀 (podman) | ⏭ | cephadm 서버에서 수행 예정 |
| F.5 | Lock 파일 (2세션 동시) | ⏭ | 파괴적, skip |
| F.6 | SSH 안정성 체크 | ⏭ | 파괴적, skip |
| F.7 | Invalid profile | ✅ | --profile foo → exit 2 확인 |
| F.8 | Exclude 병합 | ⏭ | 미수행 |
| F.9 | Plain log ANSI 없음 | ✅ | ANSI 코드 0건 확인 |
| F.10 | 사후검증 sshd down 탐지 | ⏭ | 파괴적, skip |

### 주요 검증 상세

**F.7 (invalid profile)**
- `--profile foo` 실행 → ERROR 메시지 + help 출력 + exit 2 정상 확인 ✅

**F.9 (plain log ANSI)**
- 평문 로그(.plain.log)에서 `grep -cP '\x1b\['` 결과 0건 ✅
- 주의: 테스트 스크립트 내 `grep -c` 가 0 매칭 시 exit 1 반환하여 false negative 출력됐으나 실제 스크립트 결과는 정상. 테스트 평가 로직 문제 (스크립트 버그 아님)

- **판정**: ✅

---

## 발견 버그 (3건)

| ID | 심각도 | Phase | 설명 | 상태 |
|----|--------|-------|------|------|
| BUG-H | P2 | C | plan 파일 cascade_count 64 vs dry-run summary 28 불일치 | ✅ Fixed v5.0.5 |
| BUG-I | P2 | D | 개별 apt-get purge 시 가상 패키지 gap → 신규 패키지 자동 설치 | ✅ Fixed v5.0.6 |
| BUG-J | P3 | D | sysstat 제거 후 timer 유닛 failed 상태 잔류 | KI-05 등록, 수동 reset-failed |

### BUG-H 상세

- **발견 시점**: Phase C dry-run 후 plan-k8s-worker.yaml 검토 중
- **원인**: BUG-03(v5.0.1) 수정 시 dry-run summary는 `actual_cascade`로 수정했으나 write_plan() 내 plan 파일 출력 변수(`total_cascade`)는 수정 누락
- **수정 내용**: v5.0.5, write_plan() 라인 994 변수명 교체
- **검증**: v5.0.5 dry-run 후 plan 파일 `cascade_count: 28` 일치 확인 ✅

### BUG-I 상세

- **발견 시점**: Phase D v5.0.5 execute 완료 후 dpkg.log 사후 분석
- **영향 패키지**: systemd-coredump, python3-zstandard (2개)
- **원인 상세**:
  - `apport-core-dump-handler` ↔ `systemd-coredump`: 동일한 `core-dump-handler` 가상 패키지를 Provides/Conflicts
  - 개별 purge 시 apt는 각 단계에서 의존성 그래프를 재계산
  - `apport-core-dump-handler` 제거 후 `core-dump-handler` 빈자리 발생 → apt가 `systemd-coredump`로 채움
  - pending 상태 systemd 업그레이드(255.4-8.14→8.15)가 이 과정에서 함께 처리됨
- **`--no-upgrade` 플래그 검토**: `apt-get purge --no-upgrade` 시에도 `0 upgraded, 2 newly installed` — 해결 불가
- **`apt-get upgrade -y` 검토**: 운영환경 변경관리 절차 위반 — 채택 불가
- **확정 해결책**: 전체 패키지를 단일 배치 호출로 제거. apt가 전체 제거 목록을 한 번에 해결하므로 가상 패키지 gap 없이 `0 newly installed`
  - 검증: `apt-get -s purge <all_20_pkgs>` → `0 upgraded, 0 newly installed, 22 to remove`
- **수정 내용**: v5.0.6
  - `real_removal()`: 개별 루프 → `apt-get -y purge "${to_purge[@]}"` 배치 호출
  - 배치 실패 시 fallback 개별 purge (오류 격리)
  - `check_pending_upgrades()`: execute 전 pending 업그레이드 탐지 WARN (NON-BLOCKING)
  - `verify_no_new_packages()`: execute 전후 패키지 집합 비교 자동 검증
- **v5.0.6 재검증**: `OK: 신규 패키지 없음 — execute 전후 패키지 집합 동일` ✅

### BUG-J 상세

- **발견 시점**: Phase D 사후 검증 중 `systemctl list-units --failed` 확인
- **영향 유닛**: sysstat-collect.timer, sysstat-summary.timer
- **원인**: systemd in-memory 상태 유지. purge 후 unit 파일 삭제되어도 failed 상태 기억
- **조치**: `systemctl reset-failed` 수동 처리
- **미수정 이유**: sysstat 외 패키지에서 일반적으로 재현 어려움. v5.1 사후검증 단계에 `reset-failed` 추가 검토

---

## 주요 검증 확인

| 검증 항목 | 결과 | 비고 |
|-----------|------|------|
| BUG-A (autoremove whitelist 보호) | ✅ | autoremove 0개 (93개 apt-mark manual 동작) |
| BUG-B (kubelet storm 탐지) | ✅ | NRestarts=6261 탐지 → 자동 mask/stop |
| BUG-H (plan cascade_count 정확도) | ✅ | 28개 정확 기록 (v5.0.5) |
| BUG-I (배치 purge 신규 패키지 방지) | ✅ | 신규 패키지 없음 (v5.0.6) |
| BUG-01 (rollback 복원) | ✅ | 22패키지 전량 복원, comm diff 0건 |
| test-nn2 Phase E skip 보완 | ✅ | rollback 검증 완료 |

---

## 다음 서버로 인계 사항

1. **v5.0.6 사용** — 배치 purge, pending 업그레이드 탐지, 신규 패키지 검증 포함
2. **kubelet unmask 필요**: `sudo systemctl unmask kubelet`
3. **BUG-I (KI-04)**: execute 전 `apt-get -s upgrade`로 pending 업그레이드 수 확인 권장. v5.0.6 check_pending_upgrades()가 자동 탐지/경고함
4. **BUG-J (KI-05)**: execute 후 `sudo systemctl reset-failed` 실행 권장 (timer failed 잔류 정리)
5. **apt-mark manual 대량 변경**: protect_whitelist_packages()로 92~93개 패키지 manual 설정됨 — autoremove 시 추가 제거 없을 것
6. **htop, sysstat**: k8s-worker 프로파일에서는 제거 대상에 포함 (test-nn generic에서만 제외 지시)
7. **rollback 후 잔류 정리**: python3-zstandard (v5.0.5 BUG-I 잔류) 수동 purge 완료

---

## 산출물 목록

| 파일 | 위치 | 비고 |
|------|------|------|
| auto-detect.log | test-results/test-nn3/ | 프로파일 자동감지 |
| dryrun-k8s-worker.log | test-results/test-nn3/ | v5.0.4 dry-run |
| dryrun-k8s-worker-v5.0.5.log | test-results/test-nn3/ | v5.0.5 dry-run (BUG-H 수정 후) |
| plan-k8s-worker.yaml | test-results/test-nn3/ | cascade_count: 28 (v5.0.5 수정) |
| risk-k8s-worker.log | test-results/test-nn3/ | risk report |
| execute-k8s-worker.log | test-results/test-nn3/ | v5.0.5 실행 (BUG-I 발생 이력) |
| execute-v5.0.6-verify.log | test-results/test-nn3/ | v5.0.6 재검증 (신규 패키지 없음 확인) |
| rollback-execute.log | test-results/test-nn3/ | rollback 실행 로그 |
| rollback-verification-dpkg.txt | test-results/test-nn3/ | dpkg-selections diff (BUG-I 잔류 2줄) |
| rollback-verification-manual.txt | test-results/test-nn3/ | apt-mark diff (184줄 — manual 부작용) |
| edge-case-results-test-nn3.md | test-results/test-nn3/ | F.1~F.10 결과 |
| baseline-test-nn3-*.tar.gz | test-results/test-nn3/ | 사전 백업 (dpkg+apt-mark+/etc) |
| host-minimize-safe-v5.0.5.sh | scripts/ | BUG-H 수정 |
| host-minimize-safe-v5.0.6.sh | scripts/ | BUG-I 수정 (배치 purge + 검증 함수) |
| CHANGELOG.md | docs/ | v5.0.5~5.0.6 변경 기록 |
| KNOWN-ISSUES.md | docs/ | KI-04, KI-05 추가 |
