# host-minimize-safe v5.x 운영자 가이드

**대상 독자**: SCPv2 인프라 운영자, 보안 담당자  
**관련 통제**: CSAP 2.4(평문 프로토콜), 8.5(민감정보 유출), 9.3(불필요 서비스/패키지 제거)  
**최신 버전**: v5.0.7 (2026-04-27)  
**지원 OS**: Ubuntu 22.04 / 24.04 (Noble)

---

## 목차

1. [스크립트 개요 및 목적](#1-스크립트-개요-및-목적)
2. [사전 조건](#2-사전-조건)
3. [CLI 옵션 완전 정리](#3-cli-옵션-완전-정리)
4. [노드 프로파일](#4-노드-프로파일)
5. [제거 대상 패키지](#5-제거-대상-패키지)
6. [보호(Whitelist) 패키지](#6-보호whitelist-패키지)
7. [실행 전 자동 안전 점검](#7-실행-전-자동-안전-점검)
8. [실행 흐름 단계별 해설](#8-실행-흐름-단계별-해설)
9. [로그 및 산출물 파일](#9-로그-및-산출물-파일)
10. [Rollback(복원) 절차](#10-rollback복원-절차)
11. [표준 운영 시나리오](#11-표준-운영-시나리오)
12. [출력 해석 방법](#12-출력-해석-방법)
13. [자주 발생하는 경고 및 대처](#13-자주-발생하는-경고-및-대처)
14. [알려진 제약사항(KNOWN-ISSUES)](#14-알려진-제약사항known-issues)
15. [변경 이력 요약](#15-변경-이력-요약)

---

## 1. 스크립트 개요 및 목적

`host-minimize-safe`는 SCPv2 운영 서버에서 **불필요 패키지를 안전하게 제거**하기 위한 Bash 스크립트다.

### 무엇을 하는가

1. 현재 서버의 역할(프로파일)을 감지하거나 지정받는다.
2. 역할에 맞는 **보호 목록(Whitelist)**을 구성한다.
3. CSAP 제거 대상 패키지 중 Whitelist에 없는 것을 **제거 후보**로 선정한다.
4. 제거 전 전체 의존성을 분석하여 **보호해야 할 패키지가 연쇄 제거되지 않음**을 검증한다.
5. 사용자 확인 후 실제 제거를 수행하고 결과를 검증한다.
6. 언제든 원래 상태로 **복원**할 수 있는 Rollback 스크립트를 생성한다.

### 왜 이 스크립트가 필요한가

일반 `apt-get purge`로 패키지를 제거하면:
- `autoremove`가 Whitelist 패키지(systemd 관련 등)까지 연쇄 제거할 수 있다.
- 가상 패키지(virtual package) 충돌로 제거 중 의도치 않은 패키지가 **자동 설치**될 수 있다.
- kubelet 같은 서비스가 재시작 루프 상태이면 daemon-reload 과부하로 **서버 hang**이 발생한다.
- 롤백 수단 없이 제거하면 서비스 복구가 어렵다.

이 스크립트는 위의 위험을 모두 사전에 탐지하고 안전하게 처리한다.

---

## 2. 사전 조건

| 항목 | 요구사항 |
|------|---------|
| 권한 | `sudo` 또는 root |
| OS | Ubuntu 22.04 / 24.04 |
| 디스크 여유 | `/var/lib/host-minimize` 기준 **1GB 이상** |
| APT 상태 | `dpkg --audit` 오류 없음, `apt-get check` 이상 없음 |
| 다른 APT 프로세스 | 실행 중 없음 (lock 파일 미점유) |
| 권장 사전 조치 | LVM 스냅샷 생성 (`--skip-snapshot-check`로 건너뜀 가능) |
| K8s 노드 | 패키지 제거 전 `kubectl cordon <node>` 권장 |
| Ceph 노드 | 클러스터 상태 `HEALTH_OK` 필요 |

---

## 3. CLI 옵션 완전 정리

```
sudo host-minimize-safe-v5.x.sh [OPTIONS]
```

| 옵션 | 인자 | 기본값 | 설명 |
|------|------|--------|------|
| `--profile` | `PROFILE` | `auto` | 노드 역할 지정. [4절 참조](#4-노드-프로파일) |
| `--execute` | — | false (dry-run) | 실제 제거 수행. **없으면 dry-run만** |
| `--risk-report` | — | false | 패키지별 위험도 보고서 출력 |
| `--full-tree` | — | false | 각 패키지 의존성 트리 표시 |
| `--plan-out` | `FILE` | — | dry-run 결과를 YAML 파일로 저장 |
| `--exclude` | `PKG[,PKG...]` | — | 제거 대상에서 특정 패키지 제외 |
| `--yes` | — | false | 모든 확인 프롬프트 자동 승인 (자동화용) |
| `--skip-snapshot-check` | — | false | LVM 스냅샷 권고 화면 건너뜀 |
| `--skip-ssh-check` | — | false | NIC Link Down 사전 점검 건너뜀 |
| `--verbose` | — | false | apt 명령 출력 실시간 표시 + DEBUG 로그 |
| `-h`, `--help` | — | — | 도움말 출력 |

### 종료 코드(Exit Code)

| 코드 | 의미 |
|------|------|
| `0` | 성공 |
| `1` | root 권한 없음 / 일반 실패 |
| `2` | 잘못된 `--profile` 값 / Critical 역의존 발견 |

---

## 4. 노드 프로파일

스크립트는 실행 서버의 역할에 따라 **서로 다른 보호 목록**을 적용한다.

### 프로파일 종류

| 프로파일 | 대상 서버 | 주요 추가 보호 |
|----------|----------|--------------|
| `auto` | 자동 감지 | 아래 조건으로 판별 |
| `k8s-worker` | Kubernetes Worker | kubelet, containerd, runc, cni-plugins, socat, conntrack 등 |
| `k8s-control` | Kubernetes Control Plane | k8s-worker 보호 + haproxy, keepalived |
| `cephadm` | Ceph (cephadm 관리) | podman, ceph-*, runc, crun, skopeo, containers-common 등 |
| `ceph` | Ceph (전통 배포) | ceph-*, xfsprogs, smartmontools 등 |
| `compute` | OpenStack Compute | qemu-*, libvirt-*, openvswitch-*, ovn-*, dnsmasq 등 |
| `network` | 네트워크 어플라이언스 | frr, bird, keepalived, haproxy, nginx, strongswan 등 |
| `generic` | 범용 서버 | COMMON_WHITELIST만 적용 |

### auto 감지 로직

```
1. cephadm 바이너리 존재 + /var/lib/ceph 디렉토리  → cephadm
2. ceph.conf 존재 + ceph-(osd|mon|mgr|mds) 서비스   → ceph
3. kubelet active + kube-apiserver.yaml 존재         → k8s-control
4. kubelet active                                     → k8s-worker
5. libvirtd active 또는 qemu-system-x86_64 존재     → compute
6. frr/bird/keepalived active                         → network
7. 해당 없음                                          → generic
```

> **주의**: 테스트 환경처럼 kubelet이 비활성인 경우 auto 감지는 `generic`으로 떨어진다.  
> 이 경우 `--profile k8s-worker`를 명시적으로 지정해야 한다.

---

## 5. 제거 대상 패키지

스크립트는 `DEFAULT_SAFE_REMOVE` 목록과 현재 설치 패키지를 대조하여 후보를 선정한다.  
선정된 후보 중 프로파일 Whitelist에 해당하는 것은 **자동 제외**된다.

### 카테고리별 제거 대상

#### ① 평문 프로토콜 (CSAP 2.4.1 — 필수 제거)

| 패키지 | 설명 |
|--------|------|
| `telnet`, `inetutils-telnet` | 평문 Telnet 클라이언트 |
| `ftp`, `tnftp` | 평문 FTP 클라이언트 |
| `rsh-client`, `rsh-server` | 평문 Remote Shell |
| `tftp`, `tftpd` | TFTP |
| `talk`, `talkd` | 메시지 서비스 |

#### ② 크래시/버그 리포트 (CSAP 8.5 — 민감정보 유출 방지)

| 패키지 | 설명 |
|--------|------|
| `apport` | Ubuntu 크래시 자동 수집 |
| `apport-symptoms` | apport 증상 플러그인 |
| `apport-core-dump-handler` | 코어덤프 핸들러 |
| `whoopsie` | Ubuntu 에러 리포트 전송 |
| `ubuntu-report` | 시스템 메트릭 외부 송신 |
| `popularity-contest` | 패키지 사용 통계 송신 |

#### ③ 불필요 서비스/패키지 (CSAP 9.3)

| 패키지 | 설명 |
|--------|------|
| `snapd` | Snap 패키지 매니저 |
| `git` | VCS (개발 도구, 서버 상주 금지) |
| `subversion`, `mercurial` | 기타 VCS |

#### ④ 디버그/트레이스 도구 (CSAP 9.3 — 별도 승인 없이 상주 금지)

| 패키지 | 설명 | 운영 시 대안 |
|--------|------|-------------|
| `strace` | 시스템콜 트레이서 | 필요 시 APT 미러에서 즉시 설치 |
| `gdb` | GNU 디버거 | `kubectl debug` 사이드카 이미지 |
| `crash` | 커널 코어덤프 분석 | kdump 분석 도구 (별도 관리) |
| `bpftrace` | eBPF 기반 분석 | 필요 시 즉시 설치 |
| `bpfcc-tools` | BCC 툴셋 (biolatency 등) | 필요 시 즉시 설치 |
| `trace-cmd` | ftrace 프론트엔드 | 필요 시 즉시 설치 |

#### ⑤ 터미널 멀티플렉서

| 패키지 | 대안 |
|--------|------|
| `screen` | `systemd-run` |
| `tmux` | `systemd-run` |
| `byobu` | — |

#### ⑥ 성능 모니터링 도구

| 패키지 | 설명 |
|--------|------|
| `htop` | 인터랙티브 프로세스 모니터 (top 대체) |
| `sysstat` | sar 데이터 수집 서비스 |
| `iotop` | I/O 모니터 |
| `nethogs`, `iftop` | 네트워크 모니터 |

#### ⑦ DNS 진단 도구

| 패키지 | 설명 |
|--------|------|
| `bind9-dnsutils` | dig, nslookup |
| `bind9-host` | host 명령 |

#### ⑧ GUI / 멀티미디어 (Compute 서버에 해당)

`gnome-*`, `xserver-xorg*`, `gdm3`, `lightdm`, `libreoffice*`, `vlc`, `audacity` 등

---

## 6. 보호(Whitelist) 패키지

프로파일별로 보호 패키지가 결정된다. **이 목록에 해당하는 패키지는 절대 제거되지 않는다.**

### 공통 Whitelist (모든 프로파일)

| 분류 | 패키지 예시 |
|------|------------|
| init/core | `systemd*`, `dbus*`, `udev`, `sudo`, `coreutils`, `bash` |
| 커널/부트 | `linux-image*`, `linux-modules*`, `grub*`, `initramfs-tools*`, `lvm2` |
| 네트워크 기본 | `netplan.io`, `isc-dhcp-client`, `netbase` |
| 보안/CSAP | `apparmor*`, `auditd`, `aide*`, `unattended-upgrades` |
| 패키지 관리 | `apt`, `dpkg`, `gnupg*`, `ca-certificates` |
| 원격 접속 | **`openssh-server`**, `openssh-client` |
| 로그/시간 | `rsyslog`, `logrotate`, `chrony` |
| 필수 텍스트 도구 | `vim-tiny`, `nano`, `grep`, `sed`, `tar`, `gzip` |

> `openssh-server`는 **어떤 프로파일에서도 절대 제거되지 않는다.**

### 프로파일별 추가 Whitelist

#### k8s-worker / k8s-control

```
kubelet, kubeadm, kubectl, kubernetes-cni, cri-tools
containerd*, runc, podman, cni-plugins
socat, conntrack, ipset, ethtool, ebtables
```

> `containerd`, `runc`, `kubelet`은 절대 제거되지 않는다.

#### cephadm

```
podman, containers-common, runc, catatonit, crun, slirp4netns
uidmap, fuse-overlayfs, skopeo, buildah
ceph*, rados*, rbd*, librados*, ceph-common
xfsprogs, smartmontools, nvme-cli, hdparm
```

> `cephadm` 프로파일에서 `podman`은 보호된다.  
> `DEFAULT_SAFE_REMOVE`에 `podman`이 포함되어 있지만, Whitelist가 우선 적용된다.

#### compute

```
qemu*, libvirt*, virtiofsd, openvswitch*, ovn*
dnsmasq*, conntrack, ebtables, bridge-utils
numactl, cpu-checker, hwloc*
```

---

## 7. 실행 전 자동 안전 점검

스크립트는 실제 제거 전에 다음 항목을 자동으로 점검한다.  
점검 실패 시 **즉시 중단**된다.

### 점검 항목 상세

#### 1) root 권한 확인
```
[EUID -eq 0] 검사 → 실패 시 exit 1
```

#### 2) apt/dpkg Lock 점검
```
대상 파일:
  /var/lib/dpkg/lock-frontend
  /var/lib/dpkg/lock
  /var/lib/apt/lists/lock

점유 중이면 CRIT 로그 출력 + 점유 프로세스 표시 후 exit 1
```

#### 3) 디스크 여유 공간
```
/var/lib/host-minimize 기준 1GB 미만 시 CRIT + exit 1
```

#### 4) SSH 안정성 점검 (`--skip-ssh-check`로 건너뜀 가능)
```
최근 30분 내 NIC Link Down 로그(dmesg) 발견 시 CRIT
  - SATA/ATA 이벤트는 제외 (오탐 방지)
```

#### 5) Ceph Health 점검 (ceph/cephadm 프로파일만)
```
ceph health 가 HEALTH_OK 가 아니면 CRIT + exit 1
```

#### 6) kubelet restart storm 탐지 (k8s 프로파일만)
```
NRestarts > 50 (STORM_THRESHOLD) 시 경고 + mask/stop 제안
  - 승인 시: systemctl stop + mask kubelet 자동 실행
  - 거부 시: --execute 모드에서 "그래도 계속?" 2차 확인
  - --yes 시: 자동 승인
```

> **배경**: test-nn2에서 NRestarts=572 상태로 execute 실행 시 시스템 hard hang 발생.  
> systemd-coredump 제거 후 daemon-reload가 과부하된 systemd를 deadlock시킨 사례.

#### 7) systemd 전체 서비스 storm 점검
```
failed + activating 상태 서비스 중 NRestarts > 50인 서비스 목록 경고
```

#### 8) snapd 사전 안전 점검
```
snap list 확인 → 설치된 snap이 있으면 경고 + 수동 제거 안내
  - --yes 시 경고만 하고 진행
  - snap 있는 상태에서 snapd 제거 시 dpkg hang 위험
```

#### 9) pending 업그레이드 탐지
```
apt-get -s upgrade 로 대기 중인 업그레이드 확인
  - 있으면 WARN 출력 후 계속 진행 (block 안 함)
  - 프로덕션 권장: 업그레이드 먼저 완료 후 실행
```

#### 10) LVM 스냅샷 권고 (`--skip-snapshot-check`로 건너뜀)
```
--execute 모드에서 LVM 스냅샷이 없으면 경고 + 확인 요청
```

---

## 8. 실행 흐름 단계별 해설

### 전체 흐름

```
[시작]
  │
  ├─ 인자 파싱 → 프로파일 결정
  │
  ├─ 사전 점검 (7절) → 실패 시 중단
  │
  ├─ Baseline 저장 (dpkg 상태, 서비스, 포트, /etc 스냅샷)
  │
  ├─ Rollback 스크립트 생성
  │
  ├─ 제거 후보 선정 (DEFAULT_SAFE_REMOVE ∩ 설치됨 - Whitelist)
  │
  ├─┬─ [--risk-report] 위험도 보고서 출력 → 종료
  │ │
  │ └─ [dry-run / --execute] 분석 실행
  │      │
  │      ├─ Phase 1: Critical 역의존 검사
  │      │   └─ Whitelist 패키지가 제거 후보에 역의존하면 CRIT + exit 2
  │      │
  │      ├─ Phase 2: 연쇄 제거 수 계산 + 위상 정렬
  │      │   └─ 패키지별 직접(DIRECT) / 연쇄(CASCADE) 제거 수 표시
  │      │
  │      ├─ DRY-RUN SUMMARY 출력
  │      │   └─ [--plan-out] YAML 파일 저장
  │      │
  │      └─ [--execute만] 실제 제거 실행
  │           ├─ 사용자 최종 확인 (YES 입력)
  │           ├─ batch purge (전체 패키지 한 번에)
  │           ├─ Whitelist apt-mark manual 설정
  │           ├─ autoremove (Whitelist 침범 시 자동 중단)
  │           └─ 사후 검증 (sshd, apparmor, dpkg audit, 신규 패키지)
  │
[종료]
```

### Phase 1: Critical 역의존 검사

제거 후보 각각에 대해 **역의존 패키지**를 조회하여 그 중 Whitelist에 해당하는 것이 있는지 확인한다.

```
예: 만약 containerd가 제거 후보에 포함됐고,
    kubelet이 containerd에 Depends라면:
    kubelet은 k8s-worker Whitelist에 있으므로 → CRIT
    exit 2 로 중단
```

이 검사를 통과한 패키지만 실제 제거 대상이 된다.

### Phase 2: 연쇄 제거 분석

출력 예시:
```
  PACKAGE                               DIRECT    CASCADE CSAP
  -------                               ------    ------- ----
  ftp                                        3          1 2.4.1 (평문 프로토콜 금지)
  apport                                     4          6 8.5 (민감정보 유출 방지)
  snapd                                      1          2 9.3 (불필요 서비스 제거)
```

- **DIRECT**: 이 패키지에 직접 역의존하는 패키지 수
- **CASCADE**: apt 시뮬레이션 기준 연쇄 제거될 총 패키지 수
- **CSAP**: 해당 CSAP 통제 항목

### DRY-RUN SUMMARY

```
╔══════════════════════════════════════════════════════════╗
║ DRY-RUN v5.0 SUMMARY  (node: k8s-worker)
╠══════════════════════════════════════════════════════════╣
║   직접 제거 대상     :   20 개
║   연쇄 제거 예상     :   28 개   ← apt 시뮬레이션 기준
║   총 영향 패키지     :   48 개
╚══════════════════════════════════════════════════════════╝
```

> **연쇄 제거 예상 vs 실제**: apt 시뮬레이션 기준 연쇄 수(28)는 과대 추정이다.  
> Whitelist apt-mark manual 보호 적용 후 실제 제거는 훨씬 적다.  
> (test-nn3, test-scn 실측: 연쇄 2개만 실제 제거됨 — ubuntu-server/standard 메타패키지)

### 실제 제거(--execute) 핵심 동작

#### batch purge (핵심)
```bash
apt-get -y purge pkg1 pkg2 pkg3 ... pkgN
```
모든 패키지를 **한 번의 명령**으로 제거한다.  
개별 제거 시 가상 패키지(virtual package) 충돌로 의도치 않은 패키지가 자동 설치되는 문제를 방지한다.

#### Whitelist 보호 (autoremove 전 필수)
```bash
apt-mark manual <whitelist-package-1> <whitelist-package-2> ...
```
autoremove가 Whitelist 패키지를 제거하지 못하도록 **manual 마킹**을 먼저 설정한다.

#### autoremove 안전 처리
1. dry-run으로 제거 예정 목록을 먼저 확인
2. 목록에 Whitelist 패키지가 있으면 **자동 중단**
3. systemd 계열 패키지가 포함되면 별도 경고 + 확인
4. 이상 없을 때만 실제 실행

---

## 9. 로그 및 산출물 파일

스크립트 실행 후 생성되는 파일들:

### 로그 파일

| 경로 | 설명 |
|------|------|
| `/var/log/host-minimize/minimize-v5-<TS>.log` | ANSI 컬러 포함 메인 로그 |
| `/var/log/host-minimize/minimize-v5-<TS>.plain.log` | ANSI 없는 순수 텍스트 로그 (grep/awk 분석용) |

`<TS>` = `YYYYmmdd-HHMMSS` 형식 타임스탬프

### 상태 파일

| 경로 | 설명 |
|------|------|
| `/var/lib/host-minimize/baseline/<TS>/` | 제거 전 스냅샷 디렉토리 |
| `/var/lib/host-minimize/baseline/<TS>/dpkg-selections.txt` | dpkg 패키지 선택 상태 |
| `/var/lib/host-minimize/baseline/<TS>/dpkg-l.txt` | 전체 패키지 목록 |
| `/var/lib/host-minimize/baseline/<TS>/apt-manual.txt` | manual 마킹 패키지 목록 |
| `/var/lib/host-minimize/baseline/<TS>/services-running.txt` | 실행 중 서비스 |
| `/var/lib/host-minimize/baseline/<TS>/ports.txt` | 열린 포트 목록 |
| `/var/lib/host-minimize/baseline/<TS>/etc-snapshot.tar.gz` | /etc 전체 압축 백업 |
| `/var/lib/host-minimize/rollback/rollback-v5-<TS>.sh` | 롤백 스크립트 |
| `/var/lib/host-minimize/rollback/pre-removal-selections.txt` | 제거 전 dpkg 선택 상태 |
| `/var/lib/host-minimize/minimize.lock` | 중복 실행 방지 lock 파일 |
| `/var/lib/host-minimize/kubelet-masked-by-script.txt` | kubelet mask 마커 (해당 시) |

### --plan-out 파일 형식

```yaml
# host-minimize-safe-v5 plan
generated_at: 2026-04-27T06:11:13+00:00
node_type: k8s-worker
direct_count: 20
cascade_count: 28
packages:
  - ftp
  - telnet
  - apport
  - ...
```

CSAP 감사 증빙, 다음 서버 사전 검토, 승인 문서 첨부 등에 활용한다.

---

## 10. Rollback(복원) 절차

### 1단계: 스크립트 내장 Rollback (권장)

```bash
# 가장 최근 rollback 스크립트 확인
sudo ls -lt /var/lib/host-minimize/rollback/rollback-v5-*.sh | head -3

# 실행 (인터랙티브)
sudo /var/lib/host-minimize/rollback/rollback-v5-<TS>.sh
```

rollback 스크립트 동작:
1. `apt-get update` 실행
2. `pre-removal-selections.txt`에서 `install` 상태 패키지 추출
3. 현재 미설치(`!ii`) 패키지만 `apt-get install --no-install-recommends`로 복원
4. `pre-removal-manual.txt` 기반으로 apt-mark manual 복원

### 2단계: 외부 백업 기반 수동 복원

```bash
BACKUP_DIR="$HOME/minimize-test-backup/<hostname>/<TS>"

# dpkg 선택 상태 복원
sudo dpkg --set-selections < "$BACKUP_DIR/dpkg-selections.txt"
sudo apt-get -f install

# /etc 설정 복원 (필요한 파일만 선택)
tar -tzf "$BACKUP_DIR/etc.tar.gz" | grep nginx  # 목록 확인
sudo tar -xzf "$BACKUP_DIR/etc.tar.gz" -C / etc/nginx/  # 선택 복원
```

### 3단계: 서버 재프로비저닝

1, 2단계로 복구가 안 되는 경우 테스트 서버를 재구성한다.

### Rollback 후 검증

```bash
# 패키지 복원 수 확인
dpkg -l | awk '/^ii/ {print $2}' | wc -l

# dpkg 무결성
sudo dpkg --audit && sudo apt-get check

# SSH 접근 유지
sudo ss -tlnp | grep ':22'

# 서비스 상태
systemctl is-active sshd apparmor rsyslog chrony
```

---

## 11. 표준 운영 시나리오

### 시나리오 A: 최초 실행 — dry-run으로 확인

```bash
# 1. 프로파일 자동 감지 + dry-run
sudo ./host-minimize-safe-v5.x.sh

# 2. 결과를 plan 파일로 저장 (승인 문서용)
sudo ./host-minimize-safe-v5.x.sh \
  --plan-out /tmp/plan-$(hostname).yaml

# 3. 위험도 보고서 확인
sudo ./host-minimize-safe-v5.x.sh --risk-report

# 4. 의존성 트리 상세 보기
sudo ./host-minimize-safe-v5.x.sh --full-tree
```

### 시나리오 B: K8s Worker 노드 적용

```bash
# 1. 프로파일 명시 dry-run (kubelet 비활성 환경에서도 동작)
sudo ./host-minimize-safe-v5.x.sh --profile k8s-worker

# 2. 검토 후 실제 실행 (인터랙티브)
#    kubelet이 restart storm 상태이면 스크립트가 mask 여부를 물어봄
sudo ./host-minimize-safe-v5.x.sh \
  --profile k8s-worker \
  --execute \
  --skip-snapshot-check

# 3. 자동화 실행 (CI/CD, Ansible 등)
sudo ./host-minimize-safe-v5.x.sh \
  --profile k8s-worker \
  --execute \
  --yes \
  --skip-snapshot-check

# 4. 일부 패키지 제외 (예: strace는 운영팀 요청으로 유지)
sudo ./host-minimize-safe-v5.x.sh \
  --profile k8s-worker \
  --execute \
  --exclude strace,htop
```

### 시나리오 C: Ceph 노드 (podman 보호 검증)

```bash
# dry-run: podman이 제거 대상에 없는지 반드시 확인
sudo ./host-minimize-safe-v5.x.sh --profile cephadm

# podman이 출력에 보이면 즉시 중단 — Whitelist 문제
# 정상 출력에 podman 없음 확인 후 진행
sudo ./host-minimize-safe-v5.x.sh \
  --profile cephadm \
  --execute \
  --skip-snapshot-check
```

> **cephadm 노드에서 podman 제거 시 cephadm 전체 동작 불가.**  
> dry-run 결과 반드시 확인 후 진행할 것.

### 시나리오 D: 특정 패키지만 유지하고 싶을 때

```bash
# /etc/host-minimize/exclude.conf 파일로 영구 제외 설정
sudo mkdir -p /etc/host-minimize
sudo tee /etc/host-minimize/exclude.conf << 'EOF'
# 이 파일에 한 줄씩 패키지명 입력
# 주석은 # 으로 시작
strace     # 운영팀 장애 진단 도구 — 유지 결정
sysstat    # 성능 모니터링 유지 (2026-06 재검토)
EOF

# 이후 실행 시 exclude.conf가 자동으로 적용됨
sudo ./host-minimize-safe-v5.x.sh --profile k8s-worker
```

### 시나리오 E: 실행 결과 확인

```bash
# 제거 전후 패키지 수 비교
dpkg -l | awk '/^ii/ {print $2}' | wc -l

# 제거된 패키지 목록 확인 (plain 로그)
grep 'batch purge\|Removing\|Purging' \
  /var/log/host-minimize/minimize-v5-<TS>.plain.log

# 사후 검증 결과만 확인
grep -A 30 '=== 사후 검증 ===' \
  /var/log/host-minimize/minimize-v5-<TS>.log

# 신규 패키지 탐지 여부
grep '신규 패키지' \
  /var/log/host-minimize/minimize-v5-<TS>.log
```

---

## 12. 출력 해석 방법

### 로그 레벨

| 레벨 | 색상 | 의미 |
|------|------|------|
| `[OK   ]` | 초록 | 정상 완료 |
| `[INFO ]` | 초록 | 진행 상황 정보 |
| `[WARN ]` | 노랑 | 주의 필요 — 진행은 계속됨 |
| `[ERROR]` | 빨강 | 오류 발생 — 확인 필요 |
| `[CRIT ]` | 빨강 | 심각한 오류 — 즉시 중단 |
| `[RISK ]` | 자홍 | 위험도 정보 |
| `[DEBUG]` | 청록 | 상세 디버그 (`--verbose` 시만) |

### 정상 실행 로그 패턴

```
[INFO ] Version 5.0.7 / ...
[OK   ] apt/dpkg lock 사용 가능
[OK   ] SSH 안정성 체크 통과
[WARN ] kubelet 비활성 — 테스트/준비 환경으로 간주...  ← 테스트 환경 정상
[WARN ] ⚠ apt pending 업그레이드 N개 탐지             ← 프로덕션에선 사전 처리 권장
[OK   ] Baseline 저장: /var/lib/host-minimize/...
[OK   ] Rollback 스크립트 생성: ...
...
[OK   ] batch purge 완료 (경과=18s)
[OK   ] whitelist 패키지 92개 apt-mark manual 완료
[OK   ] autoremove 대상 없음 (whitelist 보호 완료)
[OK   ] sshd 포트 22 listen 유지
[OK   ] dpkg --audit 이상 없음
[OK   ] 신규 패키지 없음
[OK   ] === 제거 작업 완료 ===
```

### 즉시 중단해야 하는 로그 패턴

```
[CRIT ] 다른 apt/dpkg 프로세스가 실행 중          → 대기 후 재시도
[CRIT ] Ceph cluster 상태: HEALTH_WARN             → ceph 상태 복구 후 재시도
[CRIT ] N건의 critical 역의존 발견                 → Whitelist 검토 필요
[CRIT ] autoremove 대상에 whitelist 패키지 포함    → 수동 apt-mark manual 처리
[CRIT ] TIMEOUT: batch purge가 600초 초과          → dpkg/apt 상태 점검
[CRIT ] sshd 포트 22 listen 하지 않음              → 즉시 sshd 재시작!
```

---

## 13. 자주 발생하는 경고 및 대처

### ① kubelet restart storm 탐지

```
[WARN ] ⚠ kubelet RESTART STORM 탐지 (NRestarts=137, 임계치=50)
```

**원인**: 테스트/준비 환경에서 kubelet이 설정 없이 재시작을 반복하는 상태  
**대처**:
- 인터랙티브 실행 시: `yes` 입력 → 스크립트가 자동으로 stop + mask
- 자동화 실행 시: `--yes` 플래그 사용 → 자동 승인
- 완료 후: `sudo systemctl unmask kubelet` 실행

### ② pending 업그레이드 경고

```
[WARN ] ⚠ apt pending 업그레이드 28개 탐지
```

**원인**: `apt-get upgrade`를 아직 수행하지 않은 상태  
**대처**:
- 프로덕션: 변경관리 절차에 따라 **업그레이드 먼저** 완료 후 스크립트 실행
- 테스트: 경고 무시하고 진행 가능 (v5.0.6+ batch purge로 영향 최소화됨)

### ③ ubuntu-server/ubuntu-standard 연쇄 제거

```
[INFO ] cascade: ubuntu-server ubuntu-standard (연쇄 2개)
```

**원인**: 두 메타패키지가 CSAP 제거 대상(`ftp`, `apport` 등)을 Depends로 선언  
**대처**: 이것은 **정상 동작**이다. 메타패키지는 기능이 없는 껍데기로 제거되어도 실질적 서비스 영향 없음 (KI-02)

### ④ dpkg-selections diff 있음 (rollback 후)

```bash
diff "$BACKUP_DIR/dpkg-selections.txt" <(sudo dpkg --get-selections)
```

출력이 있을 때:
```
> snapd                                                  deinstall
```

**원인**: snapd 등 일부 패키지가 `purge`(완전 제거) 대신 `deinstall`(설정 잔류) 상태로 기록  
**대처**: `comm` 비교로 실제 설치 패키지 집합이 동일한지 확인 (대부분 문제 없음)

### ⑤ autoremove 대상에 whitelist 패키지 포함

```
[CRIT ] autoremove 대상에 whitelist 패키지 포함됨 — autoremove를 중단합니다!
        침범 패키지: systemd-coredump
```

**원인**: apt의 internal auto-install 마킹이 Whitelist와 불일치  
**대처**: 스크립트가 자동으로 중단한다. 수동으로 `sudo apt-mark manual <패키지>`로 보호 후 재시도

---

## 14. 알려진 제약사항(KNOWN-ISSUES)

| ID | 심각도 | 증상 | 우회 방법 |
|----|--------|------|----------|
| KI-01 | P3 | rollback 시 `--no-install-recommends` 미적용 전 버전에서 Recommends 패키지 추가 설치 | rollback 후 `dpkg -l` 비교, 초과분 수동 purge |
| KI-02 | P3 | ubuntu-server/ubuntu-standard 메타패키지 연쇄 제거 | 의도된 동작, 실질 영향 없음 |
| KI-03 | P3 | dmesg 타임스탬프 파싱 실패 시 NIC Link Down 체크 false negative | `--skip-ssh-check` 후 수동 확인 |
| KI-04 | P2 | pending 업그레이드 있을 때 purge 중 신규 패키지 자동 설치 가능 | 사전 `apt-get upgrade` 완료 후 실행 |
| KI-05 | P3 | ~~purge 후 systemd timer failed 상태 잔류~~ | **v5.0.7에서 자동 처리됨** |

---

## 15. 변경 이력 요약

| 버전 | 일시 | 주요 변경 |
|------|------|----------|
| v5.0 | 2026-04-21 | 최초 출시. v4.2 치명적 버그 4건 수정. Risk Report, Plan Export, 프로파일 세분화 |
| v5.0.1 | 2026-04-23 | BUG-01~05: rollback 복원 실패, k8s-worker 체크 과도, cascade count 오류, NIC 오탐, rc 상태 오인식 |
| v5.0.2 | 2026-04-23 | BUG-06: SATA 이벤트가 NIC Link Down으로 오탐 |
| v5.0.3 | 2026-04-23 | **P0 BUG-A: autoremove Whitelist 우회 수정** (test-nn2 hang 사후 분석). BUG-B~G: storm 탐지, O(N²) 중복, timeout, snapd 안전 점검 |
| v5.0.4 | 2026-04-23 | kubelet restart storm 자동 stop/mask 기능 추가 |
| v5.0.5 | 2026-04-23 | BUG-H: plan 파일 cascade_count 불일치 수정 |
| v5.0.6 | 2026-04-24 | **BUG-I: 개별 purge → batch purge** (가상 패키지 gap 방지). pending 업그레이드 탐지, 신규 패키지 사후 검증 |
| v5.0.7 | 2026-04-27 | `--verbose` 옵션 추가. `apt_exec()` 헬퍼. **BUG-J: purge 후 failed 유닛 자동 reset-failed** |

---

## 부록: 빠른 참조 카드

```bash
# 현재 서버에 무엇을 제거하는지 확인 (항상 먼저)
sudo ./host-minimize-safe-v5.x.sh

# 위험도 리포트
sudo ./host-minimize-safe-v5.x.sh --risk-report

# plan 파일 저장 (승인 문서용)
sudo ./host-minimize-safe-v5.x.sh --plan-out ./plan-$(hostname).yaml

# 실제 실행 (K8s Worker, 인터랙티브)
sudo ./host-minimize-safe-v5.x.sh --profile k8s-worker --execute --skip-snapshot-check

# 자동화 실행
sudo ./host-minimize-safe-v5.x.sh --profile k8s-worker --execute --yes --skip-snapshot-check

# 일부 패키지 제외
sudo ./host-minimize-safe-v5.x.sh --profile k8s-worker --execute --exclude strace,sysstat

# Rollback
sudo ls -lt /var/lib/host-minimize/rollback/ | head -3
sudo /var/lib/host-minimize/rollback/rollback-v5-<TS>.sh

# kubelet unmask (execute 후 필요시)
sudo systemctl unmask kubelet && sudo systemctl start kubelet

# 로그 확인
sudo tail -f /var/log/host-minimize/minimize-v5-<TS>.plain.log
```
