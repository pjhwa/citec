# 테스트 보고서: test-scn (k8s-worker) — 2026-04-27

## 서버 정보

| 항목 | 값 |
|------|-----|
| 호스트명 | test-scn |
| 테스트 ID | test-scn-20260427 |
| 프로파일 | k8s-worker |
| OS | Ubuntu 24.04.4 LTS (Noble Numbat) |
| 테스트 일시 | 2026-04-27 |
| 사용 스크립트 IN | host-minimize-safe-v5.0.7.sh (v5.0.6에서 인수) |
| 사용 스크립트 OUT | host-minimize-safe-v5.0.7.sh (CHANGELOG 업데이트, 신규 버그 없음) |
| 번들 모드 | 계주 (test-nn3 인수) |
| 초기 패키지 수 | 691개 (ii 상태 기준) |
| 최종 패키지 수 (rollback 후) | 691개 |

---

## Phase A — 환경 진단

### 번들 모드 판별
- 번들 파일 발견: CHANGELOG.md, summary.md, KNOWN-ISSUES.md, test-matrix.csv, host-minimize-safe-v5.0.7.sh 등
- **판정: 계주 서버 모드** (test-nn3 번들 인수)

### 이전 서버(test-nn3) 버그 검토
- BUG-H (P2, plan cascade_count 불일치) → Fixed v5.0.5 ✅
- BUG-I (P2, 개별 purge 가상 패키지 gap → 신규 패키지 자동 설치) → Fixed v5.0.6 ✅
- BUG-J (P3, sysstat timer failed 잔류) → KI-05 등록, v5.0.7에서 자동 처리로 수정 ✅
- 미해결 이슈: KI-01~05 (프로덕션 영향 제한적 또는 없음)

### ⚠ 발견: v5.0.7 CHANGELOG 누락
- 번들에 v5.0.7.sh 존재하나 CHANGELOG에 항목 없음
- bundle-verify.sh 버전 불일치 조건 해당 (script=5.0.7, changelog 마지막=5.0.6)
- **조치**: CHANGELOG에 v5.0.7 항목 추가 완료 (verbose 모드, apt_exec(), BUG-J 자동 처리 기록)

### 환경 체크
| 항목 | 결과 |
|------|------|
| OS | Ubuntu 24.04.4 LTS ✅ |
| 디스크 (/) | 79GB 여유 ✅ |
| sudo | OK ✅ |
| apt-get check | 이상없음 ✅ |
| dpkg --audit | 이상없음 ✅ |
| systemd | 255.4-1ubuntu8.15 ✅ |
| 초기 패키지 수 | 691개 (ii) ✅ |

### 번들 무결성 검증 (§16.3)
- 필수 파일 5종: ✅
- 스크립트 존재: ✅
- 원본 md5 대조: ✅ (d4d0acec... 일치)
- summary.md 서버 섹션: ✅
- **판정: ✅**

---

## Phase B — 패키지 정합성

| 항목 | 값 |
|------|-----|
| 기준 파일 | test-scn_apt_list.txt (691개) |
| 현재 설치 | 691개 (ii 기준) |
| 설치 필요 | 0개 |
| 제거 후보 | 0개 |
| 조치 | none (완전 정합) |

**판정: ✅**

---

## Phase C — Dry-run

### C.2 프로파일 자동 감지
- auto 감지 결과: **generic**
- 이유: kubelet 비활성 (테스트 환경), BUG-02 수정 후 정상 동작 (CRIT 없음)
- k8s-worker 명시 필요 ✅ (예상 동작)

### C.3 명시 dry-run (k8s-worker)

**직접 제거 목록 (20개)**:
`apport`, `apport-core-dump-handler`, `apport-symptoms`, `bind9-dnsutils`, `bind9-host`,
`bpfcc-tools`, `bpftrace`, `byobu`, `crash`, `ftp`, `git`, `htop`, `inetutils-telnet`,
`screen`, `snapd`, `strace`, `sysstat`, `telnet`, `tmux`, `trace-cmd`

| 항목 | 값 |
|------|-----|
| 직접 제거 | 20개 |
| 연쇄 제거 예상 | 28개 |
| 총 영향 | 48개 |
| plan cascade_count | 28 (BUG-H 수정 확인 ✅) |
| 소요 시간 | 약 3.5분 (Phase 2 apt 시뮬레이션) |

### 주요 경고 (정상 동작)
1. **kubelet restart storm**: NRestarts=99 (임계치 50) → mask/stop 제안 (dry-run 중 stdin 없어 자동 거부, execute 시 --yes 플래그로 자동 승인)
2. **pending 업그레이드 28개**: apparmor, coreutils, kubelet 등 → WARN 후 진행

### C.5 보호 체크리스트

**공통**:
- ✅ openssh-server 제거 대상 없음
- ✅ systemd*, udev, dbus* 제거 대상 없음
- ✅ apt, dpkg 제거 대상 없음
- ✅ telnet, ftp, snapd, apport 제거 대상 포함

**k8s-worker**:
- ✅ containerd*, runc, kubelet, kubeadm, kubectl 제거 대상 없음
- ✅ cni-plugins, conntrack, socat 보호
- ✅ baseline / rollback 디렉토리 생성

**판정: ✅**

---

## Phase D — Execute

### 사전 조치
- 외부 백업 생성: `/home/citec/minimize-test-backup/test-scn/20260427-061734/` (7종 파일)
- kubelet mask: NRestarts=137 → `--yes` 플래그로 자동 승인 → stop + mask 완료

### 실행 타임라인
| 시각 | 이벤트 |
|------|--------|
| 06:17:41 | execute 시작 |
| 06:17:42 | kubelet storm(137회) 탐지 → --yes 자동 mask |
| 06:17:45 | pending 업그레이드 28개 WARN |
| 06:17:47 | baseline 저장 완료 |
| 06:17:48 | snapd: 설치된 snap 없음 확인 → 안전 제거 |
| 06:21:32 | dry-run phase 완료 (약 3.5분) |
| 06:21:50 | batch purge 완료 (18초) |
| 06:21:51 | autoremove 전 whitelist 92개 apt-mark manual |
| 06:21:53 | autoremove 대상 없음 (whitelist 보호 완전 동작) |
| 06:22:01 | 사후 검증 완료 |

### 직접 제거 목록 (20개)
`ftp`, `telnet`, `inetutils-telnet`, `apport`, `apport-symptoms`, `apport-core-dump-handler`,
`byobu`, `screen`, `tmux`, `strace`, `crash`, `bpftrace`, `bpfcc-tools`, `trace-cmd`,
`git`, `bind9-dnsutils`, `bind9-host`, `htop`, `sysstat`, `snapd`

### 연쇄 제거 (cascade)
- autoremove 대상: 0개 (whitelist 92개 apt-mark manual 보호 완전 동작 ✅)
- cascade 실제: ubuntu-server, ubuntu-standard (KI-02, 실질 영향 없음)
- **실제 제거: 22개** (691 → 669패키지)

### 발견 사항
- **BUG-J/KI-05 v5.0.7 자동 수정 확인**: `sysstat` 제거 후 failed 유닛 1개 탐지 → `systemctl reset-failed` 자동 실행 → ✅ 완료
  - test-nn3에서는 수동 처리 필요했으나 v5.0.7에서 완전 자동화됨
- **신규 패키지**: 0개 (BUG-I 배치 purge 수정 재확인 ✅)

### 사후 검증

| 항목 | 결과 |
|------|------|
| sshd:22 listen | ✅ (ssh.socket active) |
| apparmor | ✅ active |
| rsyslog | ✅ active |
| chrony | ✅ active |
| auditd | ⏭ inactive (미설치, 정상) |
| dpkg --audit | ✅ 이상없음 |
| apt-get check | ✅ 이상없음 |
| failed 유닛 | ✅ 0건 (reset-failed 자동 처리) |
| 신규 패키지 | ✅ 0개 |

**판정: ✅**

---

## Phase E — Rollback 검증

### E.1 스크립트 내장 Rollback
- 대상: `rollback-v5-20260427-061741.sh`
- 결과: `0 upgraded, 22 newly installed, 0 to remove` ✅
- 모든 22개 패키지 전량 복원

### E.2 외부 백업 기반 Diff

| 검증 항목 | diff 줄 수 | 결과 |
|-----------|-----------|------|
| dpkg-selections diff | **0줄** | ✅ 완전 복원 |
| apt-manual diff | **0줄** | ✅ 완전 복원 |

> test-nn3 대비 개선: test-nn3에서는 dpkg 2줄, apt-manual 184줄 diff가 있었으나 test-scn에서는 둘 다 0줄로 완전 일치.

**판정: ✅**

---

## Phase F — Edge Case

| # | 항목 | 결과 | 비고 |
|---|------|------|------|
| F.1 | set -e 버그 회귀 | ✅ | dry-run 완주 (Phase C) |
| F.2 | --full-tree grep 매칭 | ✅ | ftp/telnet 트리 정상 |
| F.3 | 로케일 (ko_KR.UTF-8) | ✅ | 동일 결과 (직접20/총48) |
| F.4 | podman 보호 | ⏭ | cephadm 서버 전용 |
| F.5 | Lock 파일 동시 실행 | ⏭ | 파괴적 — skip |
| F.6 | SSH 안정성 체크 | ⏭ | 파괴적 — skip |
| F.7 | Invalid profile (exit 2) | ✅ | exit code 2 확인 |
| F.8 | Exclude 병합 | ⏭ | 기능 변경 없어 skip |
| F.9 | plain log ANSI 없음 | ✅ | 0건 |
| F.10 | sshd down 탐지 | ⏭ | 파괴적 — skip |

**판정: ✅**

---

## 발견 버그 (0건 신규)

이번 서버에서 신규 버그 없음.

### 기존 버그 수정 재확인 사항
| 항목 | 확인 내용 | 결과 |
|------|-----------|------|
| BUG-H (plan cascade_count) | plan-k8s-worker.yaml: cascade_count=28 | ✅ 정상 |
| BUG-I (배치 purge) | 신규 패키지 0개 | ✅ 정상 |
| BUG-J (reset-failed) | 자동 처리 확인 (v5.0.7) | ✅ 수정됨 |
| BUG-A (autoremove whitelist) | autoremove 0패키지 | ✅ 정상 |
| BUG-B (kubelet storm) | NRestarts=137 자동 탐지/mask | ✅ 정상 |

---

## 주요 검증 확인 표

| 항목 | test-nn3 결과 | test-scn 결과 | 개선 여부 |
|------|--------------|--------------|---------|
| 실제 제거 수 | 22개 | 22개 | 동일 (일관성 ✅) |
| autoremove 추가 제거 | 0개 | 0개 | 동일 ✅ |
| rollback dpkg diff | 2줄 | 0줄 | 개선 ✅ |
| rollback apt-manual diff | 184줄 | 0줄 | 개선 ✅ |
| reset-failed 처리 | 수동 | 자동 (v5.0.7) | 개선 ✅ |

---

## 다음 서버로 인계 사항

1. v5.0.7 사용 (CHANGELOG에 전체 내용 반영 완료)
2. kubelet unmask 필요: `sudo systemctl unmask kubelet`
3. execute 후 `systemctl reset-failed` 는 v5.0.7부터 자동 처리 — 수동 불필요
4. pending 업그레이드 28개 지속 탐지 — 프로덕션에서는 사전 업그레이드 권장
5. rollback 완전성: dpkg-selections diff 0줄, apt-manual diff 0줄로 완벽 복원 확인
6. test-scn에서 신규 버그 0건 — 수렴 추세 시작

---

## 산출물 목록

| 파일명 | 위치 | 비고 |
|--------|------|------|
| test-report-test-scn.md | docs/ | 이 파일 |
| host-minimize-safe-v5.0.7.sh | scripts/ | CHANGELOG 업데이트 |
| CHANGELOG.md | docs/ | v5.0.7 항목 추가 (verbose, BUG-J 자동처리) |
| plan-auto.yaml | test-results/test-scn/ | generic 프로파일 plan |
| plan-k8s-worker.yaml | test-results/test-scn/ | k8s-worker 명시 plan |
| dryrun-k8s-worker.log | test-results/test-scn/ | dry-run 전체 로그 |
| risk-k8s-worker.log | test-results/test-scn/ | risk report |
| execute-k8s-worker.log | test-results/test-scn/ | execute 전체 로그 |
| rollback-verification-dpkg.txt | test-results/test-scn/ | diff 0줄 |
| rollback-verification-manual.txt | test-results/test-scn/ | diff 0줄 |
| auto-detect.log | test-results/test-scn/ | 자동 감지 로그 |
