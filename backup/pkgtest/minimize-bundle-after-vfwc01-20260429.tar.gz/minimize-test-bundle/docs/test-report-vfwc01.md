# 테스트 보고서 — vfwc01 (compute / GUI 서버)

| 항목 | 내용 |
|------|------|
| **서버** | vfwc01 |
| **OS** | Ubuntu 24.04.4 LTS (Noble) |
| **커널** | 6.8.0-110-generic |
| **프로파일** | compute (GUI/GNOME 환경) |
| **테스트 일시** | 2026-04-29 (KST) |
| **투입 버전** | v5.0.8 |
| **산출 버전** | v5.0.9 |
| **릴레이 순서** | 5번째 (test-nn → test-nn2 → test-nn3 → test-scn → **vfwc01**) |
| **테스터** | Jerry (CI-TEC) + Claude Code |

---

## Phase A — 사전 환경 진단

### A.1 서버 상태
- SSH 접속: ✅ 정상
- OS: Ubuntu 24.04.4 LTS Noble (x86_64)
- 역할: GUI compute 서버 (GNOME Desktop 환경)
- 네트워크: 정상

### A.2 번들 검증
- 이전 서버(test-scn) 번들 수신 및 checksum 검증: ✅ 통과
- 투입 스크립트: `host-minimize-safe-v5.0.8.sh`

### A.3 패키지 상태
```
총 설치 패키지: 1,663개 (apt-lists/test-vfwc01_apt_list.txt)
dpkg --audit: 이상 없음
apt-get check: 이상 없음
```

---

## Phase B — 프로파일 자동 감지

### B.1 auto-detect 결과
- `--profile auto` 감지: **compute** (GNOME/GUI 환경 확인)
- compute 프로파일 선택 확인: ✅

### B.2 사전 점검 통과 항목
- apt/dpkg lock: ✅ 가용
- SSH 소스 IP: ✅ 확인
- 서비스 storm: ✅ 없음
- snapd snap 목록: ✅ 설치된 snap 없음 (기본 snap 3개 only)
- pending upgrades: ✅ 없음

---

## Phase C — Dry-run 분석

### C.1 타임라인

| 시각 (UTC) | 이벤트 |
|------------|--------|
| 02:20 | v5.0.8 dry-run 1차 시도 |
| 02:20 | **CRASH** — `[CRITICAL] libpam-gnome-keyring → depends on it: gnome-keyring` (exit 2) |
| 02:20 | BUG-K 1부 발견 (--no-recommends 누락) |
| 02:25 | v5.0.8 패치 (get_direct_dependents() --no-recommends 추가) |
| 02:25 | dry-run 2차 시도 |
| 02:25 | **CRASH** — pipefail propagation at line 1103 (exit 1) |
| 02:25 | BUG-K 2부 발견 (|| true 누락) |
| 02:25 | v5.0.8 패치 완료 (|| true 추가) → Jerry 승인 |
| ~02:27 | dry-run 3차 시도 — 성공 |

### C.2 Dry-run 결과 (v5.0.8 수정 후)
```
직접 제거 대상  :  76 개
연쇄 제거 예상  :  52 개
총 영향 패키지  : 128 개
```

### C.3 Risk Report 요약
- CRITICAL 항목: 0
- WARNING 항목: 없음 (주요 서비스 영향 없음)
- 판정: 제거 안전

### C.4 발견된 버그

#### BUG-K P1 — get_direct_dependents() Recommends를 hard dep으로 오인
- **증상**: `libpam-gnome-keyring → depends on it: gnome-keyring` CRIT exit 2
- **원인 1**: `apt-cache rdepends`에 `--no-recommends` 없음 → Recommends(소프트)가 hard Depends로 오인
- **원인 2**: `--no-recommends` 추가 후 rdep 없는 패키지에서 grep exit 1 → `set -Euo pipefail` 연쇄 crash
- **수정 1**: `get_direct_dependents()` 내 `apt-cache rdepends`에 `--no-recommends` 추가
- **수정 2**: 파이프라인 끝에 `|| true` 추가 — exit 1 propagation 차단
- **버전**: v5.0.7 → v5.0.8 (Jerry 승인)
- **영향 범위**: compute 프로파일 (처음 발견). gnome-* 설치 환경 전반

---

## Phase D — Execute 실행

### D.1 사전 승인
- Jerry 명시 승인: ✅ ("안전하게 패키지제거가 가능하다는 분석이 나오면 execute도 실행하라")
- Dry-run 위험 항목: 없음 → 조건 충족

### D.2 Execute 백업
- 외부 백업 경로: `~/minimize-test-backup/vfwc01/20260429-023645/`
  - `dpkg-selections.txt`
  - `dpkg-l.txt`
  - `apt-manual.txt`
  - `dpkg-audit.txt`
  - `services.txt`

### D.3 Execute 타임라인

| 시각 (UTC) | 이벤트 |
|------------|--------|
| 02:36:53 | v5.0.8 --execute 시작 |
| 02:36:53 | Version 5.0.8, node type: compute 확인 |
| 02:41:14 | batch purge 실행 시작 |
| 02:41:55 | **batch purge 완료 (경과 41s)** — 76개 직접 제거 |
| 02:41:55 | autoremove 전 whitelist 107개 apt-mark manual 설정 |
| 02:41:58 | autoremove 대상 없음 (whitelist 보호 완료) |
| 02:42:02 | 사후 검증 — 아직 설치된 대상: 0개 ✅ |
| 02:42:12 | **WARN: 신규 패키지 2개 설치됨** (BUG-L) |
| 02:42:12 | failed 유닛 4개 탐지 → systemctl reset-failed 완료 |
| 02:42:12 | === 제거 작업 완료 === |

### D.4 Execute 결과
- 직접 제거: 76개 (41초)
- autoremove 추가 제거: 0개 (whitelist 보호)
- 남은 대상: 0개 ✅

### D.5 발견된 버그

#### BUG-L P2 — gnome 가상 패키지 gap으로 신규 패키지 자동 설치
- **증상**: `notification-daemon`, `policykit-1-gnome` 2개 신규 설치
- **원인**:
  - `gnome-shell`이 `notification-daemon`, `polkit-1-auth-agent` 가상 패키지를 Provides
  - gnome-shell 제거 시 apt가 가상 패키지 공급자 빈자리를 대체 패키지로 자동 충족
  - v5.0.6 batch purge가 KI-04(core-dump-handler)는 해결하나 gnome 가상 패키지 gap은 미해결
- **처리**: 수동 `dpkg --purge notification-daemon policykit-1-gnome` 로 정리
- **주의**: `apt-get purge` 대신 `dpkg --purge` 사용 필수 — `apt-get purge` 사용 시 pending upgrades 트리거됨
  - 실제로 `apt-get purge` 오사용 → 25개 pending upgrade + xserver-xorg-input-wacom 등 추가 설치
  - 추가 설치분 모두 `dpkg --purge`로 정리 완료
- **현재 상태**: KNOWN-ISSUES KI-06으로 등록. 스크립트 수정 미적용 (v5.1 검토 예정)

---

## Phase E — Rollback 검증

### E.1 Rollback 실행

| 시각 (UTC) | 이벤트 |
|------------|--------|
| ~03:00 | rollback script 실행 |
| 03:04:23 | dpkg lock 충돌 감지 (apt이 백그라운드 실행 중) |
| 03:09:17 | lock 해소 후 rollback 재시도 |
| 03:13:xx | rollback 완료 |

- Lock 충돌 해소: apt 프로세스 종료 대기 후 재시도로 해결

### E.2 Rollback 결과
```
rollback-verification-dpkg.txt  : 0줄 ✅ (dpkg --set-selections 비교 차이 없음)
rollback-verification-manual.txt: 246줄 (정상 — apt-mark showmanual 목록)
최종 설치 패키지 수: 1,663개 (원상 복구 확인)
```

---

## Phase F — 사후 검증

### F.1 dpkg --audit
```
결과: 이상 없음 ✅
```

### F.2 apt-get check
```
결과: 이상 없음 ✅
```

### F.3 서비스 상태
```
failed units: 0 ✅ (reset-failed 적용 완료)
```

### F.4 SSH 접속
```
접속 유지: ✅ 문제 없음
```

### F.5 핵심 화이트리스트 패키지
```
openssh-server: ✅ 설치됨
kubelet: 해당 없음 (compute 프로파일)
```

### F.6 패키지 수 기준 복구 확인
```
사전: 1,663개
사후: 1,663개 ✅
```

### F.7 스크립트 종료 코드
```
dry-run (v5.0.8 수정 후): exit 0 ✅
execute: exit 0 ✅
```

### F.8 plan 파일 cascade_count 검증
```
plan-compute.yaml cascade_count: 52
dryrun-compute.log 연쇄 제거 예상: 52 ✅ 일치
```

### F.9 Plain log ANSI 코드 검사
```
v5.0.8 execute plain log ANSI 코드: 3건 (BUG-M 확인)
소스: snapd prerm hook "Failed to kill unit snap.mesa-2404.component-monitor.service"
      whoopsie prerm hook "Stopping 'whoopsie.service', but its triggering units are still active"
```

---

## BUG-M 패치 (v5.0.9)

#### BUG-M P3 — apt_exec() silent 모드: prerm hook ANSI 코드 plain log 오염
- **증상**: execute 후 PLAIN_LOG_FILE에 ANSI escape sequence 3건 잔류 (`\x1b[0m`, `\x1b[0;1;31m` 등)
- **원인**: snapd, whoopsie prerm hook이 systemctl을 호출 시 ANSI 컬러 포함 출력 → `>> PLAIN_LOG_FILE` 리다이렉트로 기록
- **수정**: `apt_exec()` silent 분기 — apt 실행 직후 `sed -i "s/${esc}\[[0-9;]*[mK]//g"` 로 PLAIN_LOG_FILE ANSI 제거
- **검증**: sed 패턴 단위 테스트 — 3개 ANSI 라인 완전 제거 확인 ✅ (re-execute 없이 코드 리뷰 + 단위 테스트로 승인)
- **버전**: v5.0.8 → v5.0.9 (Jerry 승인)

---

## 버그 요약

| ID | 심각도 | 증상 | 수정 버전 | 상태 |
|----|--------|------|-----------|------|
| BUG-K | P1 | Recommends를 hard dep 오인 → false CRIT crash | v5.0.8 | ✅ 수정 완료 |
| BUG-L | P2 | gnome 가상 패키지 gap → 신규 패키지 2개 자동 설치 | 미적용 | ⚠ KI-06 등록, v5.1 검토 |
| BUG-M | P3 | prerm hook ANSI 코드 plain log 오염 | v5.0.9 | ✅ 수정 완료 |

---

## 산출물 목록

| 파일 | 위치 | 상태 |
|------|------|------|
| `host-minimize-safe-v5.0.8.sh` | `scripts/` | ✅ |
| `host-minimize-safe-v5.0.9.sh` | `scripts/` | ✅ |
| `plan-compute.yaml` | `test-results/vfwc01/` | ✅ |
| `dryrun-compute.log` | `test-results/vfwc01/` | ✅ |
| `risk-compute.log` | `test-results/vfwc01/` | ✅ |
| `execute-compute.log` | `test-results/vfwc01/` | ✅ |
| `rollback-verification-dpkg.txt` | `test-results/vfwc01/` | ✅ |
| `rollback-verification-manual.txt` | `test-results/vfwc01/` | ✅ |
| `test-vfwc01_apt_list.txt` | `apt-lists/` | ✅ |
| 외부 백업 | `~/minimize-test-backup/vfwc01/20260429-023645/` | ✅ |

---

## Phase 통과 기록

| Phase | 결과 | 비고 |
|-------|------|------|
| A — 환경 진단 | ✅ | 1,663 패키지, compute 역할 확인 |
| B — 프로파일 감지 | ✅ | compute 자동 감지 |
| C — Dry-run | ✅ | 76+52=128, BUG-K 발견·수정 후 통과 |
| D — Execute | ✅ | 76개 제거 41s, BUG-L WARN (수동 정리) |
| E — Rollback | ✅ | 1,663개 복구, diff=0줄 |
| F — 사후 검증 | ✅ | BUG-M 발견·수정 (v5.0.9) |
| G — 번들 패키징 | 진행 중 | |

---

## 특이사항

1. **compute 프로파일 첫 번째 테스트** — GNOME/GUI 환경에서 gnome-* 패키지 군이 다수 포함되어 k8s-worker 계열과 다른 버그 패턴 발견 (BUG-K, BUG-L)
2. **릴레이 순서 조정** — 원래 계획(wproxy→log→cepho→vfwc01)에서 vfwc01로 직행. test-nonproxy/log/cepho 미테스트.
3. **dpkg --purge vs apt-get purge** — 수동 정리 시 반드시 `dpkg --purge` 사용. `apt-get purge`는 pending upgrades를 트리거하여 의도치 않은 패키지 설치 유발 확인.
