# CHANGELOG — host-minimize-safe

## v5.0.2 (2026-04-23) @ test-nn2

### BUG-06 (P2) Fix: NIC Link Down 감지가 SATA 이벤트를 오탐하는 문제
- **증상**: SATA 드라이브 link down 이벤트(`ata*: SATA link down`)가 NIC link down으로 오인식되어 CRIT 발생
- **원인**: `grep -E 'link down'` 패턴이 SATA 이벤트도 포함
- **수정**: `grep -vE 'SATA|ata[0-9]+:'` 필터 추가로 SATA/ATA 이벤트 제외

---

## v5.0.1 (2026-04-23) @ test-nn

### BUG-01 (P1) Fix: rollback 스크립트가 purge된 패키지를 복원하지 못하는 문제
- **증상**: `dpkg --set-selections` + `apt-get dselect-upgrade` 조합이 `0 newly installed` — 실제 재설치 없음
- **원인**: `dselect-upgrade`는 purge 이후 "install" 선택 상태를 무시하는 경우 발생
- **수정**: rollback 로직을 `apt-get install` 직접 호출 방식으로 교체
  - pre-removal-selections.txt 에서 `install` 상태 패키지만 추출
  - 현재 미설치(`!ii`) 패키지만 재설치 (`--no-install-recommends`)
  - apt-mark manual 복원 시 미설치 패키지 무시 처리

### BUG-02 (P2) Fix: `--profile k8s-worker` 명시 시 kubelet 비활성이면 CRIT 중단
- **증상**: 테스트 환경(kubelet 미설치)에서 `--profile k8s-worker` 사용 불가
- **원인**: `check_k8s_health()`가 PROFILE 구분 없이 모두 CRIT 처리
- **수정**: `--profile auto` 감지 경우만 CRIT, 명시적 선택 시 WARN 후 계속 진행

### BUG-03 (P2) Fix: DRY-RUN SUMMARY cascade count 과다 계산
- **증상**: 실제 43개 영향인데 스크립트가 84개(연쇄 64개)로 표시
- **원인**: 각 패키지별 cascade를 개별 합산 → 공유 의존성 중복 카운트
- **수정**: 전체 패키지를 한 번에 `apt-get -s purge --auto-remove`로 시뮬레이션하여 실제 제거 수 계산

### BUG-04 (P3) Fix: NIC Link Down 오탐으로 CRIT 처리
- **증상**: 부팅 초기 일회성 NIC link down 로그로 인해 항상 CRIT 발생
- **원인**: dmesg 최근 200줄 전체를 검색 — 시간 필터 없음
- **수정**: 최근 30분 이내 로그만 검사, 타임스탬프 파싱으로 정확도 개선

### BUG-05 (P2) Fix: `build_candidates()`가 rc 상태 패키지를 설치된 것으로 오인식
- **증상**: purge 후 설정파일만 남은(rc) 패키지가 제거 후보에 포함
- **원인**: `dpkg-query -W`는 rc 상태도 반환
- **수정**: `dpkg -l`의 `ii` 상태만 필터링하도록 변경

---

## v5.0 (2026-04-21) — 테스트 시작 버전

- v4.2 치명적 버그 4건 수정
- Risk Report 모드 추가 (`--risk-report`)
- 노드 타입 세분화 (cephadm, k8s-worker, k8s-control, compute-bare, network)
- Extended baseline (services / ports / kernel modules / /etc / routes / mounts)
- Lock 파일, SSH 안정성 사전 점검, LVM snapshot 유도
- podman/docker/containerd 런타임 whitelist 보강
- ANSI 컬러 제거된 plain-text 병렬 로그
- Plan export (`--plan-out <file>.yaml`)

## v5.0.3 (2026-04-23) — hang 사후 분석 기반 안전성 강화

### 배경
test-nn2 서버에서 --execute 실행 후 약 9분 뒤 서버 hard hang 발생.
/var/log/dpkg.log 및 journalctl 분석을 통해 복합 원인 확정.

### 원인 분석 (확정)
1. **[P0] autoremove가 whitelist를 완전히 우회** — `systemd-coredump`, `python3-systemd` 등
   28개 패키지가 whitelist에 `systemd*` 패턴이 있음에도 autoremove에 의해 제거됨.
   → autoremove는 apt의 auto-install 마킹 기반으로 동작하며 스크립트 whitelist를 무시함.
2. **[P1] kubelet restart storm 미탐지** — 테스트 환경에서 kubelet이 NRestarts=572까지
   ~93분간 재시작 루프 중이었으나 스크립트가 이를 탐지/경고하지 않음.
   → autoremove로 systemd-coredump 제거 후 daemon-reload가 과부하된 systemd를 deadlock.
3. **[P1] get_removal_order O(N²) 중복 실행** — dry_run + real_removal 각각 호출,
   19×19=361회 apt-cache 호출 → ~6분 소비.

### 수정 내역

#### [BUG-A P0] autoremove whitelist 우회 수정
- `protect_whitelist_packages()`: autoremove 전 현재 설치된 whitelist 패키지 전체
  `apt-mark manual` → autoremove 대상에서 제외
- `do_autoremove()`: autoremove 전 dry-run 결과 표시, whitelist 침범 감지 시 중단,
  systemd 계열 패키지 포함 시 별도 CRIT 경고, 사용자 확인 후 실행

#### [BUG-B P1] kubelet/서비스 restart storm 탐지 추가
- `check_k8s_health()`: `systemctl show kubelet --property=NRestarts` 확인,
  NRestarts > STORM_THRESHOLD(50) 시 경고 + --execute 모드 확인 요청
- `check_systemd_storm()`: 전체 failed/activating 서비스 restart storm 사전 점검

#### [BUG-C P1] get_removal_order 중복 실행 제거
- `ORDERED_PACKAGES` 전역 배열 캐시 도입 — 첫 번째 호출 결과 저장, 이후 재사용
- N > ORDER_SKIP_THRESHOLD(20) 시 O(N²) 위상 정렬 스킵

#### [BUG-D P1] 모든 apt 호출 timeout 적용
- `APT_TIMEOUT=120s`, `APT_CACHE_TIMEOUT=30s`, `PKG_REMOVE_TIMEOUT=300s`,
  `AUTOREMOVE_TIMEOUT=600s` 상수 추가
- `get_direct_dependents`, `count_cascade_removals`, `get_removal_order`,
  `dry_run_full_analysis`, `do_autoremove` 전체에 적용

#### [BUG-E P1] snapd 제거 전 snap 목록 사전 확인
- `check_snapd_safety()`: snap list 확인 → 설치된 snap 있으면 경고 + 수동 제거 안내
- --execute 진입 시 호출, 사용자 거부 시 snapd를 candidates에서 자동 제외

#### [BUG-D 추가] apt/dpkg lock 사전 점검
- `check_apt_lock()`: /var/lib/dpkg/lock-frontend 등 3개 lock 파일 점유 여부 확인

#### [BUG-F P2] autoremove 제거 목록 표시 (do_autoremove에서 해결)

#### [BUG-G P2] 패키지당 purge timeout
- `timeout PKG_REMOVE_TIMEOUT apt-get purge` — prerm/postrm hang 방지
- timeout 시 CRIT 로그 + 진단 명령 출력

### 파일
- `host-minimize-safe-v5.0.3.sh`

## v5.0.4 (2026-04-23) — kubelet restart loop 자동 중단 기능 추가

### 변경 내용

#### [신규 P1] check_k8s_health() — restart storm 감지 시 자동 중단 승인/실행

**동작 흐름:**
```
1. kubelet.service 유닛 존재 확인 (미설치 환경 스킵)
2. NRestarts > STORM_THRESHOLD(50) 감지 시 storm 경고 출력
3. LoadState == "masked" 이면 이미 안전 → 바로 통과
4. 사용자에게 stop + mask 수행 여부 승인 요청
   - yes → systemctl stop + mask 실행 → LoadState 검증
   - no  → --execute 모드 시 "그래도 계속?" 2차 확인 → 거부 시 exit
   - --yes 플래그 → 자동 승인
5. 성공 시 마커 파일 기록:
   ${STATE_DIR}/kubelet-masked-by-script.txt
   (masked_at, NRestarts_at_mask, unmask_cmd 포함)
6. on_exit() 에서 KUBELET_MASKED_BY_SCRIPT=true 이면 unmask 안내 출력
```

**설계 결정:**
- dry-run 모드에서도 storm 감지 시 mask 제안 (dry-run 자체도 O(N²) apt 호출로 부하)
- 프로덕션 노드 (--profile auto + kubelet active) 에서는 stop/mask 하지 않음
  → 테스트 환경 (명시적 --profile 지정) 에서만 실질 동작
- mask는 재부팅 전까지만 유효 → 테스트 완료 후 unmask 필요

### 파일
- `host-minimize-safe-v5.0.4.sh`
