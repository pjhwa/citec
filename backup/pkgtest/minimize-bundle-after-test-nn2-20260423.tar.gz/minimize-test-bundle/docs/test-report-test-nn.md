# 테스트 진행 보고서 — test-nn

| 항목 | 내용 |
|------|------|
| 서버 | test-nn |
| 날짜 | 2026-04-23 |
| OS | Ubuntu 24.04.4 LTS |
| 스크립트 시작 버전 | v5.0 |
| 스크립트 종료 버전 | v5.0.1 |
| 프로파일 | generic (auto 감지, kubelet 없음) |
| 초기 패키지 수 | 690개 (ii 상태) |
| 제거 후 패키지 수 | 670개 |
| 제거 패키지 수 | 40개 |
| 디스크 반환 | 427 MB |

---

## Phase A — 환경 진단

**판정: 첫 번째 서버 모드**

- CHANGELOG.md / summary.md 없음 → 첫 번째 서버 확정
- hostname: `test-nn`
- 기준 파일: `k-nn01-con301-krw1b_apt_list.txt`
- 디스크: / 96GB, 79GB 여유 ✅
- sudo: OK ✅
- dpkg --audit: 이상 없음 ✅
- apt-get check: 이상 없음 ✅

**⚠ 발견**: `ceph-base`, `ceph-common`, `ceph-mds`, `podman` 이 `rc` 상태 (설정파일만 잔류, 실제 미설치). 초기에 `dpkg-query -W`가 rc 상태를 포함해 제거 후보로 오보고함 → BUG-05 연결.

---

## Phase B — 패키지 정합성

**테스트 목적 재정의** (Jerry 지시):
- 목적: 현재 시스템 설치 패키지 기준으로 CSAP 불필요 패키지 식별 및 안전 삭제
- apt_list.txt 비교는 참고용, 절대 기준 아님
- 실제 서비스 없는 테스트 서버
- Dell 관리도구(`srvadmin-*`, `openwsman` 등) 절대 삭제 금지

현재 690개 패키지 그대로 진행.

---

## Phase C — Dry-run 및 Risk Report

### 프로파일 감지
- `--profile k8s-worker` 시도 → CRIT 중단 (kubelet 없음) → **BUG-02 발견**
- `auto` 감지 → `generic` 프로파일 선택 (kubelet/ceph/libvirt 없음)

### 제거 후보 (v5.0 dry-run)
- 직접 제거: 20개
- 연쇄 제거: 64개 (스크립트 표시) → 실제 27개 → **BUG-03 발견**
- v5.0.1 수정 후: 연쇄 24개로 정정

### CSAP 매핑 확인

| 패키지 | CSAP | 판정 |
|--------|------|------|
| ftp, telnet, inetutils-telnet | 2.4.1 평문 프로토콜 금지 | 제거 |
| apport, apport-symptoms, apport-core-dump-handler | 8.5 민감정보 유출 방지 | 제거 |
| snapd | 9.3 불필요 서비스 제거 | 제거 |
| git | 9.3 개발도구 상주 금지 | 제거 |
| strace, crash, bpftrace, bpfcc-tools, trace-cmd | 진단 도구 | 제거 (Jerry 승인) |
| bind9-dnsutils, bind9-host | DNS 진단 도구 | 제거 (Jerry 승인) |
| byobu, screen, tmux | 터미널 멀티플렉서 | 제거 (Jerry 승인) |
| **sysstat, htop** | **운영 도구** | **유지 (Jerry 지시)** |

### ubuntu-server/ubuntu-standard 메타패키지
- CSAP 제거 대상(ftp, apport, git 등)이 Depends이므로 연쇄 제거 불가피
- 실질 서비스 영향 없는 껍데기 패키지 → 제거 허용 (KI-02)

### 체크리스트
- [x] openssh-server 제거 대상 없음 ✅
- [x] systemd*, udev, dbus* 제거 대상 없음 ✅
- [x] apt, dpkg 제거 대상 없음 ✅
- [x] telnet, ftp, apport, snapd 제거 대상 포함 ✅
- [x] snap list 출력 없음 → snapd 제거 안전 ✅

---

## Phase D — Execute

### 외부 백업
- 위치: `~/minimize-test-backup/test-nn/20260423-013658/`
- 포함: dpkg-selections.txt, dpkg-l.txt, apt-manual.txt, apt-auto.txt, services-enabled.txt, ports.txt

### 실행 명령
```bash
sudo apt-get purge --auto-remove -y \
  apport apport-symptoms apport-core-dump-handler \
  ftp telnet inetutils-telnet \
  git snapd \
  byobu screen tmux \
  strace crash bpftrace bpfcc-tools trace-cmd \
  bind9-dnsutils bind9-host
```

### 결과
- 제거 전: 690개 → 제거 후: 647개 (초회 실행 기준)
- 디스크 반환: 427 MB

### 사후 검증
| 항목 | 결과 |
|------|------|
| sshd:22 LISTEN | ✅ |
| ssh.service active | ✅ |
| rsyslog active | ✅ |
| chrony active | ✅ |
| apparmor active | ✅ |
| dpkg --audit | ✅ 이상없음 |
| apt-get check | ✅ 이상없음 |
| Failed 유닛 | ✅ 없음 (apport.service는 reset-failed로 해소) |
| sysstat 유지 | ✅ |
| htop 유지 | ✅ |

---

## Phase E — Rollback 검증

### 1차 시도 (v5.0 내장 rollback)
- 방법: `dpkg --set-selections` + `apt-get dselect-upgrade`
- 결과: **❌ 실패** — `0 newly installed`, 43개 패키지 미복원
- 원인: `dselect-upgrade`가 purge 후 패키지를 재설치하지 않는 APT 동작
- → **BUG-01 발견**

### 수동 복원
- 방법: 백업 dpkg-selections.txt 기반 `apt-get install` 직접 호출
- 결과: ✅ 690개 완전 복원, diff 0줄

### 2차 시도 (v5.0.1 신규 rollback)
- 방법: `apt-get install -y --no-install-recommends` 방식
- 결과: ✅ 복원 성공
- 주의: Recommends 의존성으로 27개 추가 설치됨 → `--no-install-recommends` 적용으로 최소화 (KI-01)

---

## Phase F — Edge Case

| 항목 | 결과 |
|------|------|
| F.1 v4.2 Bug#1 회귀 (set -e) | ✅ dry-run 완주 |
| F.5 rc 상태 패키지 오인식 | ✅ BUG-05 발견/수정 |
| F.7 invalid profile | ✅ `--profile foo` → exit 2 |
| F.4 NIC Link Down 오탐 | ✅ BUG-04 발견/수정 |

---

## 발견 버그 및 수정 내역

| ID | 심각도 | 발견 Phase | 설명 | 수정 버전 |
|----|--------|-----------|------|-----------|
| BUG-01 | P1 | E | rollback `dselect-upgrade`가 purge 패키지 복원 못함 | v5.0.1 |
| BUG-02 | P2 | C | `--profile k8s-worker` 명시 시 kubelet 없으면 CRIT 중단 | v5.0.1 |
| BUG-03 | P2 | C | cascade count 개별 합산으로 중복 발생 (64개→24개) | v5.0.1 |
| BUG-04 | P3 | A | NIC Link Down dmesg 전체 검색으로 오탐 | v5.0.1 |
| BUG-05 | P2 | A/B | `dpkg-query -W`가 rc 상태 패키지 포함 | v5.0.1 |

---

## v5.0.1 주요 변경 사항

1. **rollback 로직 교체**: `dselect-upgrade` → `apt-get install --no-install-recommends` (설치된 것만 복원)
2. **k8s-worker 체크 완화**: 명시적 프로파일 선택 시 kubelet 비활성 → WARN 후 계속
3. **cascade count 정확화**: 전체 패키지 일괄 `apt-get -s purge` 시뮬레이션으로 중복 제거
4. **NIC 오탐 방지**: dmesg 타임스탬프 파싱으로 최근 30분 이내만 검사
5. **rc 상태 패키지 제외**: `dpkg -l | awk '/^ii/'` 방식으로 실제 설치 패키지만 처리

---

## 다음 서버 인계 사항

- 스크립트: `host-minimize-safe-v5.0.1.sh` 사용
- sysstat, htop은 운영 도구로 항상 제외 (`--exclude sysstat,htop` 또는 수동 제외)
- ubuntu-server/ubuntu-standard 메타패키지 제거는 정상 동작 (KI-02)
- rollback 후 추가 Recommends 설치분은 수동 purge 필요 (KI-01)
- Dell 관리도구(`srvadmin-*`, `openwsman` 등): rc 상태 — 건드리지 않음
- 원본 스냅샷 md5: `d4d0acec252ecb9efbd920b2cf524080` (v5.0-original-snapshot.sh)
