#!/usr/bin/env bash
# Auto-generated rollback script (v5.0.1) - 20260423-035126
set -Euo pipefail
export DEBIAN_FRONTEND=noninteractive
export LC_ALL=C.UTF-8

echo "=== ROLLBACK v5.0.1 (20260423-035126) ==="
echo "이 스크립트는 제거 전 설치 패키지를 apt-get install로 복원합니다."
echo "설정 파일은 /var/lib/host-minimize/baseline/20260423-035126/etc-snapshot.tar.gz 에서 수동 복원하세요."
read -rp "진행하시겠습니까? (yes 입력): " ok
[[ "$ok" == "yes" ]] || { echo "취소"; exit 0; }

apt-get update || true

# pre-removal-selections.txt 에서 install 상태였던 패키지만 추출
# rc(설정파일 잔류) 상태 제외, 현재 미설치 패키지만 재설치
SELECTIONS="/var/lib/host-minimize/rollback/pre-removal-selections.txt"
PKGS_TO_RESTORE=()
while IFS= read -r line; do
    pkg=$(echo "$line" | awk '{print $1}')
    state=$(echo "$line" | awk '{print $2}')
    [[ "$state" != "install" ]] && continue
    base=$(echo "$pkg" | cut -d: -f1)
    current=$(dpkg -l "$base" 2>/dev/null | awk '/^[a-z]/ {print $1}' | tail -1)
    [[ "$current" != "ii" ]] && PKGS_TO_RESTORE+=("$base")
done < "$SELECTIONS"

if (( ${#PKGS_TO_RESTORE[@]} == 0 )); then
    echo "복원할 패키지 없음 (이미 설치됨)."
else
    echo "복원 대상: ${#PKGS_TO_RESTORE[@]} 개"
    apt-get install -y --no-install-recommends "${PKGS_TO_RESTORE[@]}" || {
        echo "일부 패키지 설치 실패. 개별 재시도하거나 apt-get -f install 실행하세요."
    }
fi

# manual marking 복원
if [[ -f /var/lib/host-minimize/rollback/pre-removal-manual.txt ]]; then
    while IFS= read -r pkg; do
        dpkg -l "$pkg" 2>/dev/null | grep -q '^ii' && apt-mark manual "$pkg" 2>/dev/null || true
    done < /var/lib/host-minimize/rollback/pre-removal-manual.txt
fi

echo "=== 복원 완료. reboot 권장. ==="
echo "※ /etc 설정 복원이 필요하면:"
echo "   tar -tzf /var/lib/host-minimize/baseline/20260423-035126/etc-snapshot.tar.gz | less"
echo "   (선택적으로 파일 단위 복원 후 서비스 재시작)"
