# 테스트 보고서: test-cepho (cephadm) — 2026-05-12

## 서버 정보

| 항목 | 값 |
|------|-----|
| 호스트명 | test-cepho |
| 테스트 ID | 7번째 서버 (릴레이 순서) |
| 프로파일 | cephadm |
| OS | Ubuntu 24.04.4 LTS Noble (커널 6.8.0) |
| 테스트 일시 | 2026-05-12 04:24 ~ 05:10 UTC |
| 스크립트 IN | host-minimize-safe-v5.0.10.sh |
| 스크립트 OUT | host-minimize-safe-v5.0.11.sh |
| 번들 모드 | 계주 (test-vfwc02 인수, 6번째 서버) |
| 초기 패키지 수 | 819개 (ii 기준) |

---

## Phase A — 환경 진단

### 번들 모드 판정
- `minimize-test-bundle/` 존재 → **계주 서버 모드**
- 이전 서버: test-vfwc02 (compute, v5.0.9 → v5.0.10)

### 이전 서버 버그 검토
- BUG-N (P2, compute 전용): v5.0.10 수정 완료 확인
- KI-06 (gnome 가상 패키지 gap): cephadm 프로파일 무관
- 기타 KI-01~05: 모두 현 서버 영향 없거나 수정 완료

### 환경 체크

| 항목 | 결과 |
|------|------|
| OS | Ubuntu 24.04.4 LTS Noble ✅ |
| 디스크 | 78G 여유 (96G 중 14G 사용) ✅ |
| sudo | OK ✅ |
| apt-get check | 정상 ✅ |
| 초기 패키지 수 | 819개 (ii 기준) ✅ |
| dpkg --audit | 이상없음 ✅ |
| systemd | 255.4-1ubuntu8.12 ✅ |

**판정: ✅**

---

## Phase B — 패키지 정합성

| 항목 | 결과 |
|------|------|
| 기준 파일 | test-cepho_apt_list.txt (819개) |
| 현재 ii 패키지 | 819개 |
| 설치 필요 | 0개 |
| 제거 후보 | 0개 |
| 정합성 | **완전 정합** |

**판정: ✅**

---

## Phase C — Dry-run

### 프로파일 감지
- auto 감지: `generic` (설계상 정상 — cephadm 바이너리·/var/lib/ceph 미존재, /etc/ceph/ceph.conf 미존재)
- 명시 지정: `cephadm` (v5.0.11 BUG-O 수정 후 정상 동작)

### BUG-O 발견 및 수정 (v5.0.10 → v5.0.11)

**증상**: `--profile cephadm` 명시 시 `check_ceph_health()`가 CRIT exit 1 → dry-run 자체 불가

**원인 분석**:
- test-cepho는 `ceph-common` 패키지는 설치됐으나 `/etc/ceph/ceph.conf` 미존재 (순수 패키지 재현 서버)
- `ceph health` 명령 실행 시 `ObjectNotFound` 오류 반환
- `check_ceph_health()`가 실패 시 무조건 CRIT — `--skip-snapshot-check` 같은 우회 플래그 없음

**수정 (v5.0.11)**:
1. `check_ceph_health()` — `/etc/ceph/ceph.conf` 미존재 시 CRIT 대신 WARN 후 return 0
2. `--skip-ceph-check` 플래그 신설 (명시적 우회)

**검증**: syntax OK ✅, SCRIPT_VERSION=5.0.11 ✅

### Dry-run 결과 (v5.0.11)
- pending 업그레이드: 86개 WARN (v5.0.6+ batch purge로 최소화)
- 직접 제거: **20개**
- 연쇄 제거: **55개**
- 총 영향: **75개**

### 직접 제거 대상 20개
`apport`, `apport-core-dump-handler`, `apport-symptoms`, `bind9-dnsutils`, `bind9-host`, `bpfcc-tools`, `bpftrace`, `byobu`, `crash`, `ftp`, `git`, `htop`, `inetutils-telnet`, `screen`, `snapd`, `strace`, `sysstat`, `telnet`, `tmux`, `trace-cmd`

### 보호 체크리스트 (plan YAML 기준)

| 항목 | 결과 |
|------|------|
| openssh-server | ✅ 보호됨 |
| systemd / udev / dbus | ✅ 보호됨 |
| apt / dpkg | ✅ 보호됨 |
| telnet / ftp / snapd / apport | ✅ 제거 대상 |
| **podman** | ✅ **보호됨** ← 핵심 |
| **buildah** | ✅ **보호됨** |
| **skopeo / crun / runc** | ✅ **보호됨** (미설치 또는 보호) |
| **containers-common** (golang-github-containers-common) | ✅ **보호됨** |
| **ceph-base / ceph-common / ceph-mds** | ✅ **보호됨** |
| containernetworking-plugins | ✅ 보호됨 |
| aardvark-dns | ✅ 보호됨 |

**판정: ✅**

---

## Phase D — Execute

### 사전 조치
- 외부 백업: `~/minimize-test-backup/test-cepho/20260512-044247/` (dpkg-selections, dpkg-l, apt-manual, apt-auto, services, ports, etc.tar.gz)

### 실행 타임라인

| 시각 (UTC) | 이벤트 |
|------------|--------|
| 04:42:55 | Execute 시작 |
| 04:42:56 | SSH 안정성 체크 통과 |
| 04:42:56 | Ceph Health Check 건너뜀 (ceph.conf 미존재 WARN) |
| 04:43:00 | pending 업그레이드 86개 WARN |
| 04:43:02 | Baseline 저장 완료 |
| 04:43:03 | snapd: 설치된 snap 없음 → 안전 |
| 04:43:13 | Critical 역의존 없음 |
| 04:47:06 | batch purge 시작 (20개) |
| 04:47:30 | batch purge 완료 (24초) |
| 04:47:31 | whitelist 104개 apt-mark manual 설정 |
| 04:47:33 | autoremove 0개 (whitelist 완전 보호) |
| 04:47:42 | 사후 검증 완료 |

### 직접 제거 목록 (20개)
ftp, telnet, inetutils-telnet, apport, apport-symptoms, apport-core-dump-handler, byobu, screen, tmux, strace, crash, bpftrace, bpfcc-tools, trace-cmd, git, bind9-dnsutils, bind9-host, htop, sysstat, snapd

### 연쇄 제거 (3개)
ubuntu-server, ubuntu-server-minimal, ubuntu-standard (메타패키지, 기능 영향 없음 — KI-02)

### 총 제거: 23개 (819 → 796)

### 사후 검증 결과

| 항목 | 결과 |
|------|------|
| sshd:22 listen | ✅ |
| ssh service | ✅ active |
| rsyslog | ✅ active |
| chrony | ✅ active |
| apparmor | ✅ active |
| auditd | ⚠ inactive (테스트 서버 미구성, 서비스 영향 없음) |
| dpkg --audit | ✅ 이상없음 |
| apt-get check | ✅ 정상 |
| Failed 유닛 | ✅ 0건 (reset-failed 자동 처리 4건) |
| 신규 패키지 자동 설치 | ✅ 0개 |
| **podman 생존** | ✅ |
| **buildah 생존** | ✅ |
| **crun 생존** | ✅ |
| **ceph-base/common/mds 생존** | ✅ |
| **컨테이너/Ceph 패키지 before=after** | ✅ 18개 동일 |

**판정: ✅**

---

## Phase E — Rollback 검증

### 실행 방법
- 스크립트 내장 rollback: `/var/lib/host-minimize/rollback/rollback-v5-20260512-044255.sh`
- 복원 대상: 23개

### 검증 결과

| 항목 | 결과 |
|------|------|
| 복원 패키지 수 | 23개 전량 복원 ✅ |
| dpkg-selections diff | **0줄** ✅ |
| apt-manual diff | 199줄 (whitelist apt-mark 잔류 — 정상) |
| 실질적 패키지 집합 diff | **0줄** ✅ |
| bind9-libs | 86 → 86.3 자동 업그레이드 (pending upgrade 처리) |

**판정: ✅**

---

## Phase F — Edge Case

| # | 검증 목적 | 결과 |
|---|-----------|------|
| F.1 | set -e 회귀 | ✅ dry-run exit 0 |
| F.2 | grep 매칭 회귀 | ✅ --full-tree 정상 |
| F.3 | 로케일 회귀 | ✅ ko_KR locale 미설치 시 fallback → default locale, 동일 결과 |
| **F.4** | **podman 보호** | ✅ **plan 미포함 + 실행 후 ii 유지 (cephadm 결정적 검증 완료)** |
| F.5 | Lock 파일 | ⏭ 스킵 (파괴적) |
| F.6 | SSH 안정성 | ⏭ 스킵 (파괴적) |
| F.7 | Invalid profile | ✅ exit 2 |
| F.8 | Exclude 병합 | ⏭ 스킵 (변경 없음) |
| F.9 | plain log ANSI | ✅ 0건 |
| F.10 | sshd down 탐지 | ⏭ 스킵 (파괴적) |

**판정: ✅**

---

## 발견 버그 (1건)

| ID | 심각도 | Phase | 설명 | 상태 |
|----|--------|-------|------|------|
| BUG-O | P1 | C.3 | cephadm 프로파일: /etc/ceph/ceph.conf 미존재 테스트 환경에서 CRIT 중단 | ✅ Fixed in v5.0.11 |

### BUG-O 상세

- **발견 시점**: Phase C.3 — `--profile cephadm` 명시 dry-run 시
- **원인**: `check_ceph_health()`가 `/etc/ceph/ceph.conf` 존재 여부 미확인 → `ceph health` 실패 시 무조건 CRIT
- **수정 내용**:
  1. `/etc/ceph/ceph.conf` 미존재 시 WARN 후 return 0 (테스트 환경으로 간주)
  2. `--skip-ceph-check` 플래그 신설
- **검증 결과**: v5.0.11 재실행 시 WARN 후 정상 진행 ✅

## 주요 검증 확인 표 (이전 서버 수정 효과)

| 항목 | 결과 |
|------|------|
| BUG-A (autoremove whitelist 우회) | ✅ autoremove 0패키지, whitelist 104개 보호 완전 동작 |
| BUG-B (kubelet storm) | ✅ storm 없음 (NRestarts=0) |
| BUG-I/KI-04 (가상 패키지 gap) | ✅ 신규 패키지 0개 (batch purge 동작) |
| BUG-J/KI-05 (timer failed 잔류) | ✅ reset-failed 자동 처리 4건 |
| BUG-M (ANSI plain log 오염) | ✅ ANSI 0건 |
| BUG-N (compute GNOME 도구 누락) | cephadm 무관 |
| F.4 podman 보호 | ✅ **cephadm 결정적 검증 완료** |

---

## 다음 서버로 인계 사항

1. **v5.0.11 사용** (BUG-O 수정본)
2. **미테스트 서버**: test-wproxy, test-log — k8s-worker 프로파일 잔여 2개
3. **test-cepho에서 F.4 통과**: podman/buildah/ceph-* 모두 보호 실전 증명
4. pending 업그레이드 86개 WARN — execute 결과 신규 패키지 없음으로 v5.0.6+ batch purge 효과 확인
5. dpkg-selections diff 0줄 — rollback 완전성 유지

---

## 산출물 목록

| 파일 | 위치 | 비고 |
|------|------|------|
| host-minimize-safe-v5.0.11.sh | scripts/ | BUG-O 수정본 |
| plan-cephadm.yaml | test-results/test-cepho/ | cephadm 프로파일 plan |
| plan-auto.yaml | test-results/test-cepho/ | auto(generic) 감지 plan |
| dryrun-cephadm.log | test-results/test-cepho/ | v5.0.11 dry-run 로그 |
| risk-cephadm.log | test-results/test-cepho/ | risk report |
| execute-cephadm.log | test-results/test-cepho/ | execute 로그 |
| rollback-verification-dpkg.txt | test-results/test-cepho/ | dpkg diff (0줄) |
| rollback-verification-manual.txt | test-results/test-cepho/ | apt-manual diff |
| CHANGELOG.md | docs/ | v5.0.11 항목 추가 |
| summary.md | docs/ | test-cepho 섹션 추가 |
| BUNDLE-CHECKSUMS.txt | docs/ | v5.0.11 md5 추가 |
