# 테스트 보고서: test-cepho02 (cephadm)

- **서버**: test-cepho02
- **날짜**: 2026-05-14
- **프로파일**: cephadm
- **스크립트 버전**: v5.0.12 → v5.0.13 (이번 서버에서 신규 개발)
- **테스트 목적**: BUG-P(재부팅 방지), BUG-Q(커널 hold) 검증 + cephadm 2차 검증

---

## 환경 정보

| 항목 | 값 |
|------|-----|
| OS | Ubuntu 24.04.4 LTS (Noble) |
| 커널 | 6.8.0-110-generic (부팅 중 자동 업그레이드됨) |
| 패키지 수 (Phase A) | 828개 (ii 기준) |
| 디스크 여유 | 78G / 96G |
| systemd | 255.4-1ubuntu8.14 |
| dpkg audit | 이상 없음 |

---

## 사전 사건 기록 (Phase A 이전)

| 시각 (UTC) | 사건 |
|-----------|------|
| 02:31 | 서버 부팅 (kernel 6.8.0-101) |
| 03:18 | apt-daily-upgrade.timer 발동 (Persistent=true, 2.5개월 누적) |
| 03:19–03:24 | unattended-upgrades: linux-image-6.8.0-110 포함 65개 자동 업그레이드 |
| 03:48 | Jerry가 reboot-required 확인 후 수동 재부팅 |
| 03:48 | 재부팅 완료 (kernel 6.8.0-110) |
| 03:50 | Jerry DHCP IP 재신청 시도 (isc-dhcp-client 수동 설치) |
| 04:06 | SSH 재접속 성공 (172.16.10.236) |
| 04:10 | 원인 분석 시작 — BUG-P/Q 식별 |
| 04:30 | v5.0.12 (BUG-P), v5.0.13 (BUG-Q) 개발 완료 |

### 원인 분석
- **재부팅 원인**: `unattended-upgrades`가 `linux-image-6.8.0-110` 포함 65개 자동 업그레이드 후 `/var/run/reboot-required` 생성. `apt-daily-upgrade.timer`의 `Persistent=true` 속성으로 서버 오프라인 기간(2.5개월) 누적분이 부팅 46분 후 일괄 실행됨.
- **IP 변경 원인**: MAAS DHCP 서버(172.16.10.254)의 임대 시간 10분(T1=5분). 재부팅 시마다 MAC 기반 예약 없이 동적 풀에서 재할당.
- **스크립트와 무관**: 재부팅은 host-minimize-safe 스크립트 실행 전 발생.

---

## Phase A — 현재 상황 진단

| 항목 | 결과 |
|------|------|
| 모드 | 계주 서버 (8번째) |
| 이전 서버 | test-cepho (v5.0.11, cephadm, Phase A~F 통과) |
| 번들 필수 파일 | 5종 ✅ |
| 환경 체크 | ✅ |

---

## Phase B — 패키지 정합성

| 항목 | 값 |
|------|-----|
| 기준 파일 | test-cepho_apt_list.txt (819개) |
| 현재 패키지 | 828개 |
| 설치 필요 | 0개 |
| 초과 패키지 | 9개 |

**초과 9개 내역:**
- `linux-image/headers/modules/tools-6.8.0-110*` (7개) — 자동 업그레이드
- `isc-dhcp-client`, `isc-dhcp-common` (2개) — Jerry 수동 설치

판정: **정합** (원인 설명 가능, Phase C 진행)

---

## Phase C — Dry-run

| 항목 | 값 |
|------|-----|
| 스크립트 | v5.0.13 (syntax OK) |
| 프로파일 자동 감지 | generic (설계상 정상) |
| 명시 프로파일 | cephadm ✅ |
| 직접 제거 대상 | 20개 |
| 연쇄 제거 예상 | 54개 |
| 총 영향 | 74개 |
| pending 업그레이드 | 62개 WARN (비커널, 비차단) |
| BUG-Q hold | 커널 27개 apt-mark hold 완료 ✅ |
| BUG-Q 타이머 | 비활성 상태 — stop 불필요 ✅ |
| baseline/rollback 생성 | ✅ |

**C.5 보호 체크리스트:**
- ✅ `openssh-server` 제거 대상 아님
- ✅ `podman` 보호
- ✅ `ceph-common`, `ceph-base`, `librados2`, `librbd1`, `buildah`, `crun` 보호
- ✅ `systemd`, `udev`, `dbus`, `apt`, `dpkg` 보호
- ✅ `telnet`, `ftp`, `snapd`, `apport` 제거 대상 포함

**새 버그 없음.**

---

## Phase D — Execute

### 타임라인

| 시각 | 이벤트 |
|------|--------|
| 05:03:32 | execute 시작 (v5.0.13) |
| 05:03:32–05:03:33 | 커널 27개 hold 완료 |
| 05:03:33 | apt 타이머 비활성 확인 |
| 05:03:33 | reboot-required 없음 확인 |
| 05:07:52 | batch purge 20개 시작 |
| 05:08:14 | batch purge 완료 (22초) |
| 05:08:14–05:08:16 | whitelist 92개 apt-mark manual |
| 05:08:18 | autoremove 0개 (whitelist 보호) |
| 05:08:27 | 사후 검증 완료 |
| 05:08:27 | on_exit unhold 27개 복원 |

### 실제 제거 패키지 (20개)

```
ftp, telnet, inetutils-telnet
apport, apport-symptoms, apport-core-dump-handler
byobu, screen, tmux
strace, crash
bpftrace, bpfcc-tools, trace-cmd
git
bind9-dnsutils, bind9-host
htop, sysstat
snapd
```

### 사후 검증

| 항목 | 결과 |
|------|------|
| batch purge | 22초 완료 ✅ |
| autoremove | 0개 ✅ |
| 실제 제거 수 | 828→805 = **23개** (직접20 + 연쇄3) |
| 신규 패키지 | 0개 ✅ |
| sshd:22 | ✅ |
| ssh, rsyslog, chrony, apparmor | 모두 active ✅ |
| auditd | 미설치 (원래부터 — 제거 아님) |
| dpkg audit | 이상 없음 ✅ |
| failed units | 0개 (reset-failed 4개 자동 정리) ✅ |
| **podman** | **✅ 생존** |
| ceph-base/ceph-common/librados2/librbd1/buildah/crun | ✅ 전부 생존 |
| skopeo | 원래부터 미설치 |
| **BUG-Q hold 복원** | on_exit: 27개 unhold 완료 ✅ |

---

## Phase E — Rollback 검증

| 항목 | 결과 |
|------|------|
| 내장 rollback | 23개 전량 복원 ✅ |
| 복원 후 패키지 수 | 828개 (제거 전과 동일) ✅ |
| dpkg-selections diff | **0줄** ✅ |
| apt-manual diff | 186줄 (rollback apt-mark 동작 — KI-01 기존 인지) |

---

## Phase F — Edge Case 회귀 테스트

| # | 테스트 | 결과 | 비고 |
|---|--------|------|------|
| F.1 | set -e + (()) 회귀 | ✅ | dry-run 완주 |
| F.2 | --full-tree spot check | ✅ | ftp→tnftp, apport→python3-apport 정상 |
| F.3 | ko_KR.UTF-8 로케일 | ✅ | 제거 후보 20개 동일 |
| F.4 | podman 보호 (cephadm) | ✅ | Phase D 실전 검증 |
| F.5 | Lock 동시 실행 | ⏭ | 첫 프로세스 조기 종료 — CRIT 미발생 |
| F.6 | SSH 안정성 파괴 | ⏭ | 파괴적, 스킵 |
| F.7 | Invalid profile | ✅ | exit 2 정확히 반환 |
| F.8 | Exclude 병합 | ⏭ | 변경 없음 |
| F.9 | Plain log ANSI 없음 | ✅ | `grep -cP '\x1b\['` = 0 |
| F.10 | sshd down 탐지 | ⏭ | 파괴적, 스킵 |

---

## 발견 및 수정 버그

### BUG-P (P0) — unattended-upgrades 자동 커널 업그레이드 → 재부팅
- **발견**: Phase A 이전 (테스트 중 재부팅 사건)
- **원인**: `apt-daily-upgrade.timer` Persistent=true + 2.5개월 누적 → linux-image-6.8.0-110 자동 업그레이드 → reboot-required → 재부팅
- **수정**: v5.0.12 — `check_reboot_required()`, `check_unattended_upgrades()` 추가
- **상태**: 수정 완료 ✅

### BUG-Q (P0) — 커널 hold 미설정으로 외부 경로 커널 업그레이드 가능
- **발견**: BUG-P 분석 중 (구조적 결함)
- **원인**: COMMON_WHITELIST가 직접 purge는 막지만 apt-mark hold 없어 unattended-upgrades 등이 커널 업그레이드 가능
- **수정**: v5.0.13 — `protect_kernel_packages()`(27개 hold), `stop_apt_timers()`, `check_unattended_upgrades()` 강화, `build_candidates()` 2중 필터
- **검증**: execute 실행 중 hold 27개 완료 + on_exit unhold 복원 확인 ✅
- **상태**: 수정 완료 ✅

---

## 산출물 목록

| 파일 | 위치 |
|------|------|
| 스크립트 | `scripts/host-minimize-safe-v5.0.13.sh` |
| apt-list | `apt-lists/test-cepho02_apt_list.txt` (828개) |
| dry-run 로그 | `test-results/test-cepho02/dryrun-cephadm.log` |
| execute 로그 | `test-results/test-cepho02/execute-cephadm.log` |
| risk 리포트 | `test-results/test-cepho02/risk-cephadm.log` |
| plan 파일 | `test-results/test-cepho02/plan-cephadm.yaml` |
| rollback 검증 | `test-results/test-cepho02/rollback-verification-dpkg.txt` |

---

## 다음 서버 인계 사항

- **사용 스크립트**: v5.0.13
- **미테스트 서버**: test-wproxy, test-log (k8s-worker 프로파일)
- **cephadm 서버**: test-cepho + test-cepho02 2회 연속 통과
- **BUG-P/Q 수정**: v5.0.13 번들 포함 — 다음 서버 실행 시 커널 hold 자동 적용 확인 필요
- **주의**: MAAS 환경 DHCP 임대 시간 10분 — IP 변경 시 재접속 필요. 가능하면 MAAS에서 MAC 기반 고정 IP 예약 권장
