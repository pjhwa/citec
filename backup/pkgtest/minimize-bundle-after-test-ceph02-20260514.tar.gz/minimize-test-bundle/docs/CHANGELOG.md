# CHANGELOG — host-minimize-safe

## v5.0.13 (2026-05-14) @ test-cepho02

### [BUG-Q P0] 스크립트 실행 중/외 커널 패키지 업그레이드 → reboot-required → 자동 재부팅 방지
- **증상**: test-cepho02에서 unattended-upgrades가 linux-image-6.8.0-110 커널 업그레이드 후 /var/run/reboot-required 생성 → 재부팅 발생. COMMON_WHITELIST에 linux-image* 있으나 apt-mark hold 미설정으로 unattended-upgrades가 여전히 커널 업그레이드 가능했음
- **원인1**: apt-mark hold 없음 → unattended-upgrades 등 외부 경로로 커널 업그레이드 가능
- **원인2**: check_unattended_upgrades()의 타이머 WARN이 비차단 → 타이머 활성 상태로 스크립트 진행 허용
- **수정1**: `protect_kernel_packages()` 신규 — 스크립트 시작 시 설치된 모든 커널 관련 패키지(27개) `apt-mark hold` 고정 → 어떤 경로로도 커널 변경 불가
- **수정2**: `restore_kernel_hold()` → on_exit()에서 자동 unhold 복원
- **수정3**: `stop_apt_timers()` 신규 — apt-daily-upgrade.timer/apt-daily.timer 활성 시 즉시 stop, on_exit()에서 복원
- **수정4**: `check_unattended_upgrades()` 내 타이머 활성 → 비차단 WARN에서 즉시 stop으로 강화
- **수정5**: main() 사전 점검 순서에 protect_kernel_packages() + stop_apt_timers() 추가 (check_reboot_required 이전)
- **수정6**: build_candidates()에 커널 패키지 명시 2중 필터 (linux-image-*, linux-headers-* 등 정규식 매칭)
- **효과**: 스크립트 실행 중 커널 업그레이드 완전 차단. on_exit에서 hold/타이머 정상 복원 확인 (27개 unhold 로그 검증)
- **영향 범위**: 전 프로파일 공통

### [BUG-P P0] unattended-upgrades 자동 실행 중 커널 업그레이드 → reboot-required 상태 점검 (v5.0.12)
- **증상**: test-cepho02에서 apt-daily-upgrade.timer(Persistent=true, 임대 2.5개월 누적)가 부팅 46분 후 발동 → linux-image 포함 65개 자동 업그레이드 → reboot-required 생성 → 재부팅
- **수정1**: `check_reboot_required()` — /var/run/reboot-required 존재 시 CRIT + exit 1
- **수정2**: `check_unattended_upgrades()` — apt-daily-upgrade.service 실행 중이면 CRIT + exit 1; 타이머 활성 시 WARN
- **수정3**: main() 사전 점검 순서 추가

---

## v5.0.11 (2026-05-12) @ test-cepho

### [BUG-O P1] cephadm 프로파일: /etc/ceph/ceph.conf 미존재 테스트 환경에서 CRIT 중단 수정
- **증상**: `--profile cephadm` 명시 시 `check_ceph_health()`가 `ceph health` 실패로 CRIT exit 1 → dry-run 불가
- **원인**: 테스트 서버는 ceph-common 패키지 설치됐으나 `/etc/ceph/ceph.conf` 미존재 (실제 클러스터 미구성). `ceph health` 명령이 `ObjectNotFound` 오류 반환
- **수정1**: `check_ceph_health()` — `/etc/ceph/ceph.conf` 미존재 시 CRIT 대신 WARN 후 return 0 (테스트 환경으로 간주)
- **수정2**: `--skip-ceph-check` 플래그 추가 (명시적 우회, `--skip-snapshot-check`와 동일 패턴)
- **효과**: 테스트 환경에서 cephadm 프로파일 dry-run/execute 정상 수행. 프로덕션(`/etc/ceph/ceph.conf` 존재)에서는 기존과 동일하게 CRIT 동작
- **영향 범위**: cephadm / ceph 프로파일 전용

---

## v5.0.9 (2026-04-29) @ vfwc01

### [BUG-M P3] apt_exec() silent 모드: prerm hook ANSI 코드 plain log 오염 수정
- **증상**: execute 후 PLAIN_LOG_FILE에 ANSI escape sequence 3건 잔류 (`\x1b[0m` 등)
- **원인**: snapd, whoopsie 등 prerm hook이 systemctl을 호출 시 ANSI 컬러 코드 포함 출력 → `>> PLAIN_LOG_FILE` 리다이렉트로 그대로 기록
- **수정**: `apt_exec()` silent 분기에서 apt 실행 직후 `sed -i "s/${esc}\[[0-9;]*[mK]//g"` 로 PLAIN_LOG_FILE의 ANSI 코드 제거
- **효과**: plain log가 진정한 텍스트 전용으로 유지 → grep/awk 파이프라인 오염 없음
- **영향 범위**: verbose=false(기본값) 모드 전용 — verbose 시에는 원래 tee 경유로 문제 없음

---

## v5.0.8 (2026-04-29) @ vfwc01

### [BUG-K P1] get_direct_dependents: --no-recommends 추가 — Recommends를 hard dep으로 오인하는 false CRIT 수정
- **증상**: compute 프로파일 dry-run 시 `libpam-gnome-keyring → depends on it: gnome-keyring` CRIT exit 2
- **원인**: `apt-cache rdepends`에 `--no-recommends` 없음 → `libpam-gnome-keyring`(COMMON_WHITELIST의 `libpam*` 보호대상)이 `gnome-keyring`을 Recommends(소프트)하는데, 이를 hard Depends로 오인하여 CRIT 처리
- **수정1**: `get_direct_dependents()` 내 `apt-cache rdepends`에 `--no-recommends` 추가 (line 944)
- **수정2**: 동 함수 파이프라인 끝에 `|| true` 추가 — rdep 없는 패키지에서 grep exit 1 → `set -Euo pipefail` 연쇄 크래시 방지 (BUG-K 연장)
- **효과**: Recommends 관계는 역의존 검사에서 제외 → gnome-keyring 등 gnome-* 패키지가 정상적으로 제거 후보 처리됨
- **영향 범위**: compute 프로파일 (처음 발견), 이론상 gnome-* 설치된 모든 프로파일

---

## v5.0.7 (2026-04-27) @ test-scn (사전 준비)

### [신규] verbose 모드 및 apt_exec() 헬퍼 도입
- `VERBOSE=false` 전역 플래그 + `--verbose` CLI 옵션 추가
- `apt_exec()` 헬퍼 함수 신설:
  - verbose 모드: apt 출력을 실시간 표시 + LOG_FILE/PLAIN_LOG_FILE 동시 기록
  - silent 모드: PLAIN_LOG_FILE에만 기록, 실패 시 해당 구간 발췌를 터미널에 출력
  - 종료 코드를 변수로 반환 (`printf -v`)하여 set -e 영향 없이 오류 처리
- DEBUG 레벨 로그: `--verbose` 시에만 터미널 출력 (기존에는 항상 표시)
- `check_pending_upgrades()` timeout: 30s → `APT_TIMEOUT`(120s) 통일
- 소소한 코드 스타일 개선 1건 (`[[ ]]` 조건 단순화)

### [BUG-J P3] KI-05 Fix: purge 후 systemd failed 유닛 자동 reset-failed 처리
- **증상**: `sysstat` 등 패키지 purge 후 해당 timer/service 유닛이 `failed` 상태로 잔류
- **수정**: 사후 검증 단계에서 `systemctl list-units --failed` 확인 → 존재 시 `systemctl reset-failed` 자동 실행 + OK 로그
- **효과**: KI-05 등록 이슈 해소, 사후 검증 후 `Failed 유닛 0` 보장

---

## v5.0.6 (2026-04-24) @ test-nn3

### BUG-I (P2) Fix: apt-get purge 개별 실행 시 의도치 않은 패키지 자동 설치
- **증상**: `apt-get purge apport-core-dump-handler` 실행 시 `systemd-coredump`, `python3-zstandard` 신규 설치
- **원인**: `apport-core-dump-handler`와 `systemd-coredump`가 동일 virtual package(`core-dump-handler`)를 `Provides/Conflicts`. 개별 purge 시 apt가 빈 provider 자리를 채우기 위해 다른 provider를 자동 설치
- **핵심 수정**: `real_removal()` 개별 purge 루프 → **단일 batch purge** (`apt-get purge pkg1 pkg2 ... pkgN`). batch 해석 시 전체 제거 목록이 함께 고려되어 불필요한 대체 설치 없음. (시뮬레이션 검증: `0 newly installed`)
- **추가1**: `check_pending_upgrades()` — execute 전 pending 업그레이드 존재 시 WARN 출력. **프로덕션 환경에서 자동 upgrade 수행 없음** (변경관리 절차 존중). 경고 후 계속 진행
- **추가2**: `verify_no_new_packages()` — execute 후 사전 baseline 대비 신규 패키지 탐지 및 WARN 로깅
- **batch 실패 시 fallback**: batch purge 실패 시 개별 재시도로 원인 격리

---

## v5.0.5 (2026-04-23) @ test-nn3

### BUG-H (P2) Fix: plan 파일 cascade_count 가 실제 제거 수와 불일치
- **증상**: `--plan-out` 생성 파일의 `cascade_count` 가 dry-run summary 표시값과 다름 (예: 64 vs 28)
- **원인**: BUG-03(v5.0.1) 에서 dry-run summary는 `actual_cascade`(apt 시뮬레이션 기반)로 수정됐으나, plan 파일 기록 코드는 `total_cascade`(개별 패키지 cascade 합산, 구방식)를 그대로 사용
- **수정**: `write_plan()` 내 `cascade_count: $total_cascade` → `cascade_count: $actual_cascade`

---

## v5.0.2 (2026-04-23) @ test-nn2

### BUG-06 (P2) Fix: NIC Link Down 감지가 SATA 이벤트를 오탐하는 문제
- **증상**: SATA 드라이브 link down 이벤트(`ata*: SATA link down`)가 NIC link down으로 오인식되어 CRIT 발생
- **원인**: `grep -E 'link down'` 패턴이 SATA 이벤트도 포함
- **수정**: `grep -vE 'SATA|ata[0-9]+:'` 필터 추가로 SATA/ATA 이벤트 제외

---

## v5.0.1 (2026-04-23) @ test-nn

### BUG-01 (P1) Fix: rollback 스크립트가 purge된 패키지를 복원하지 못하는 문제
- **증상**: `dpkg --set-selections` + `apt-get dselect-upgrade` 조합이 `0 newly installed` — 실제 재설치 없음
- **원인**: `dselect-upgrade`는 purge 이후 "install" 선택 상태를 무시하는 경우 발생
- **수정**: rollback 로직을 `apt-get install` 직접 호출 방식으로 교체
  - pre-removal-selections.txt 에서 `install` 상태 패키지만 추출
  - 현재 미설치(`!ii`) 패키지만 재설치 (`--no-install-recommends`)
  - apt-mark manual 복원 시 미설치 패키지 무시 처리

### BUG-02 (P2) Fix: `--profile k8s-worker` 명시 시 kubelet 비활성이면 CRIT 중단
- **증상**: 테스트 환경(kubelet 미설치)에서 `--profile k8s-worker` 사용 불가
- **원인**: `check_k8s_health()`가 PROFILE 구분 없이 모두 CRIT 처리
- **수정**: `--profile auto` 감지 경우만 CRIT, 명시적 선택 시 WARN 후 계속 진행

### BUG-03 (P2) Fix: DRY-RUN SUMMARY cascade count 과다 계산
- **증상**: 실제 43개 영향인데 스크립트가 84개(연쇄 64개)로 표시
- **원인**: 각 패키지별 cascade를 개별 합산 → 공유 의존성 중복 카운트
- **수정**: 전체 패키지를 한 번에 `apt-get -s purge --auto-remove`로 시뮬레이션하여 실제 제거 수 계산

### BUG-04 (P3) Fix: NIC Link Down 오탐으로 CRIT 처리
- **증상**: 부팅 초기 일회성 NIC link down 로그로 인해 항상 CRIT 발생
- **원인**: dmesg 최근 200줄 전체를 검색 — 시간 필터 없음
- **수정**: 최근 30분 이내 로그만 검사, 타임스탬프 파싱으로 정확도 개선

### BUG-05 (P2) Fix: `build_candidates()`가 rc 상태 패키지를 설치된 것으로 오인식
- **증상**: purge 후 설정파일만 남은(rc) 패키지가 제거 후보에 포함
- **원인**: `dpkg-query -W`는 rc 상태도 반환
- **수정**: `dpkg -l`의 `ii` 상태만 필터링하도록 변경

---

## v5.0 (2026-04-21) — 테스트 시작 버전

- v4.2 치명적 버그 4건 수정
- Risk Report 모드 추가 (`--risk-report`)
- 노드 타입 세분화 (cephadm, k8s-worker, k8s-control, compute-bare, network)
- Extended baseline (services / ports / kernel modules / /etc / routes / mounts)
- Lock 파일, SSH 안정성 사전 점검, LVM snapshot 유도
- podman/docker/containerd 런타임 whitelist 보강
- ANSI 컬러 제거된 plain-text 병렬 로그
- Plan export (`--plan-out <file>.yaml`)

## v5.0.3 (2026-04-23) — hang 사후 분석 기반 안전성 강화

### 배경
test-nn2 서버에서 --execute 실행 후 약 9분 뒤 서버 hard hang 발생.
/var/log/dpkg.log 및 journalctl 분석을 통해 복합 원인 확정.

### 원인 분석 (확정)
1. **[P0] autoremove가 whitelist를 완전히 우회** — `systemd-coredump`, `python3-systemd` 등
   28개 패키지가 whitelist에 `systemd*` 패턴이 있음에도 autoremove에 의해 제거됨.
   → autoremove는 apt의 auto-install 마킹 기반으로 동작하며 스크립트 whitelist를 무시함.
2. **[P1] kubelet restart storm 미탐지** — 테스트 환경에서 kubelet이 NRestarts=572까지
   ~93분간 재시작 루프 중이었으나 스크립트가 이를 탐지/경고하지 않음.
   → autoremove로 systemd-coredump 제거 후 daemon-reload가 과부하된 systemd를 deadlock.
3. **[P1] get_removal_order O(N²) 중복 실행** — dry_run + real_removal 각각 호출,
   19×19=361회 apt-cache 호출 → ~6분 소비.

### 수정 내역

#### [BUG-A P0] autoremove whitelist 우회 수정
- `protect_whitelist_packages()`: autoremove 전 현재 설치된 whitelist 패키지 전체
  `apt-mark manual` → autoremove 대상에서 제외
- `do_autoremove()`: autoremove 전 dry-run 결과 표시, whitelist 침범 감지 시 중단,
  systemd 계열 패키지 포함 시 별도 CRIT 경고, 사용자 확인 후 실행

#### [BUG-B P1] kubelet/서비스 restart storm 탐지 추가
- `check_k8s_health()`: `systemctl show kubelet --property=NRestarts` 확인,
  NRestarts > STORM_THRESHOLD(50) 시 경고 + --execute 모드 확인 요청
- `check_systemd_storm()`: 전체 failed/activating 서비스 restart storm 사전 점검

#### [BUG-C P1] get_removal_order 중복 실행 제거
- `ORDERED_PACKAGES` 전역 배열 캐시 도입 — 첫 번째 호출 결과 저장, 이후 재사용
- N > ORDER_SKIP_THRESHOLD(20) 시 O(N²) 위상 정렬 스킵

#### [BUG-D P1] 모든 apt 호출 timeout 적용
- `APT_TIMEOUT=120s`, `APT_CACHE_TIMEOUT=30s`, `PKG_REMOVE_TIMEOUT=300s`,
  `AUTOREMOVE_TIMEOUT=600s` 상수 추가
- `get_direct_dependents`, `count_cascade_removals`, `get_removal_order`,
  `dry_run_full_analysis`, `do_autoremove` 전체에 적용

#### [BUG-E P1] snapd 제거 전 snap 목록 사전 확인
- `check_snapd_safety()`: snap list 확인 → 설치된 snap 있으면 경고 + 수동 제거 안내
- --execute 진입 시 호출, 사용자 거부 시 snapd를 candidates에서 자동 제외

#### [BUG-D 추가] apt/dpkg lock 사전 점검
- `check_apt_lock()`: /var/lib/dpkg/lock-frontend 등 3개 lock 파일 점유 여부 확인

#### [BUG-F P2] autoremove 제거 목록 표시 (do_autoremove에서 해결)

#### [BUG-G P2] 패키지당 purge timeout
- `timeout PKG_REMOVE_TIMEOUT apt-get purge` — prerm/postrm hang 방지
- timeout 시 CRIT 로그 + 진단 명령 출력

### 파일
- `host-minimize-safe-v5.0.3.sh`

## v5.0.4 (2026-04-23) — kubelet restart loop 자동 중단 기능 추가

### 변경 내용

#### [신규 P1] check_k8s_health() — restart storm 감지 시 자동 중단 승인/실행

**동작 흐름:**
```
1. kubelet.service 유닛 존재 확인 (미설치 환경 스킵)
2. NRestarts > STORM_THRESHOLD(50) 감지 시 storm 경고 출력
3. LoadState == "masked" 이면 이미 안전 → 바로 통과
4. 사용자에게 stop + mask 수행 여부 승인 요청
   - yes → systemctl stop + mask 실행 → LoadState 검증
   - no  → --execute 모드 시 "그래도 계속?" 2차 확인 → 거부 시 exit
   - --yes 플래그 → 자동 승인
5. 성공 시 마커 파일 기록:
   ${STATE_DIR}/kubelet-masked-by-script.txt
   (masked_at, NRestarts_at_mask, unmask_cmd 포함)
6. on_exit() 에서 KUBELET_MASKED_BY_SCRIPT=true 이면 unmask 안내 출력
```

**설계 결정:**
- dry-run 모드에서도 storm 감지 시 mask 제안 (dry-run 자체도 O(N²) apt 호출로 부하)
- 프로덕션 노드 (--profile auto + kubelet active) 에서는 stop/mask 하지 않음
  → 테스트 환경 (명시적 --profile 지정) 에서만 실질 동작
- mask는 재부팅 전까지만 유효 → 테스트 완료 후 unmask 필요

### 파일
- `host-minimize-safe-v5.0.4.sh`

---

## v5.0.10 (2026-05-11) @ test-vfwc02

### [BUG-N P2] compute 프로파일: DEFAULT_SAFE_REMOVE에 GNOME GUI 관리 도구 4개 누락 수정
- **증상**: `--execute` 후 KI-06(notification-daemon, policykit-1-gnome) 수동 정리 시 `dpkg --purge` 실패
  - update-notifier가 `gnome-shell | notification-daemon` 의존 → gnome-shell 제거 후 notification-daemon blocking
  - update-manager, network-manager-gnome이 `gnome-shell | policykit-1-gnome | polkit-1-auth-agent` 의존 → policykit-1-gnome blocking
- **원인**: update-manager, update-notifier, ubuntu-release-upgrader-gtk, network-manager-gnome의 패키지명이 `gnome-*` 패턴 미해당 → DEFAULT_SAFE_REMOVE 누락
- **수정**: DEFAULT_SAFE_REMOVE GUI 섹션에 4개 패키지 명시 등록
- **효과**: compute 프로파일 execute 시 4개 패키지가 gnome-shell과 동시 batch purge → notification-daemon / policykit-1-gnome 자동 설치 방지 (KI-06 연장 해소)
- **검증**: v5.0.10 dry-run 직접 76→80개 (+4개) 확인 ✅
- **영향 범위**: compute 프로파일 전용
